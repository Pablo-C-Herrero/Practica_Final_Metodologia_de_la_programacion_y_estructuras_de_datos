module juego {
    requires javafx.controls;
    requires javafx.fxml;

    // Abre los paquetes que JavaFX necesita acceder por reflexión (FXML + controladores)
    opens juego.Apartado_visual to javafx.fxml;
    opens juego.Apartado_visual.EstructurasUtilizadas to javafx.fxml;
    opens juego.personajes to javafx.fxml;
    opens juego.objetos to javafx.fxml;
    opens juego.turnos to javafx.fxml;
    opens juego.estructuras.Cola_Prioridad to javafx.fxml;
    opens juego.estructuras.Lista_CDE to javafx.fxml;
    opens juego.estructuras.ArbolDecision to javafx.fxml;
    opens juego.estructuras.Pila to javafx.fxml;

    exports juego.Apartado_visual;
}
