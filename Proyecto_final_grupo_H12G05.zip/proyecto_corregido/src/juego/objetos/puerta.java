package juego.objetos;

public class puerta {

    private int fila;
    private int columna;
    private boolean necesitaLlave;
    private boolean abierta;

    public puerta(int fila, int columna, boolean necesitaLlave){
        this.fila = fila;
        this.columna = columna;
        this.necesitaLlave = necesitaLlave;
        this.abierta = false;
    }

    // Getters y setters de los atributos de la clase.
    public int getFila(){ return fila; }
    public int getColumna(){ return columna; }

    public boolean estaAbierta(){ return abierta; }
    public boolean necesitaLlave(){ return necesitaLlave; }

    // Se abre la puerta.
    public void abrir(){ abierta = true; }
}