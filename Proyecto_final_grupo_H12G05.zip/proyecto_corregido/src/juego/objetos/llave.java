package juego.objetos;

public class llave extends objeto {

    public llave() { // Se mira a ver si está en el inventario del jugador para ver si se puede abrir una puerta cerrada).
        super("Llave", "Abre una puerta", "Llave");
    }
}