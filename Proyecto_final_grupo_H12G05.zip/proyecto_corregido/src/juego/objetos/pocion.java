package juego.objetos;

public class pocion extends objeto {

    private boolean quitaVeneno;
    private boolean quitaCongelacion;

    public pocion(String nombre, String descripcion) {
        super(nombre, descripcion, "Pocion");
        this.curaVida = 0;
    }


    // Getters y setters de los atributos propios y heredados que afectan a la clase.
    public void setQuitaVeneno(boolean v) { this.quitaVeneno = v; }
    public void setQuitaCongelacion(boolean v) { this.quitaCongelacion = v; }
    public boolean quitaVeneno() { return quitaVeneno;}
    public boolean quitaCongelacion() { return quitaCongelacion;}

    public void setBonusAtaque(int v) { this.bonusAtaque = v; }
    public void setBonusDefensa(int v) { this.bonusDefensa = v; }
    public void setBonusVelocidad(int v) { this.bonusVelocidad = v; }
    public int getBonusAtaque(){ return bonusAtaque;}
    public int getBonusDefensa(){ return bonusDefensa;}
    public int getBonusVelocidad(){ return bonusVelocidad;}

    public void setDuracionTurnos(int v) { this.duracionTurnos = v; }
    public int getDuracionTurnos(){ return duracionTurnos;}

    public void setCuraVida(int v) { this.curaVida = v;}
    public int getCuraVida() { return curaVida;}
}