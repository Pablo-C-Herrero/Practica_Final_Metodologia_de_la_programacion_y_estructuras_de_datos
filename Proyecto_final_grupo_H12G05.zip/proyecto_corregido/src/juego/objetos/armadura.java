package juego.objetos;

public class armadura extends objeto {

    public armadura(String nombre, String descripcion) {
        super(nombre, descripcion, "Armadura");
    }

// Getters y setters de los atributos.
    public void setBonusDefensa(int v) { this.bonusDefensa = v; } // Mejoran las defensas.
    public void setBonusVelocidad(int v) { this.bonusVelocidad = v; } // El sabatón mejora la velocidad.

    public void setPenalizacionVelocidad(int v) { this.penalizacionVelocidad = v; } // Las grabas reducen la velocidad.


    public int getBonusDefensa(){
        return bonusDefensa;
    }
}