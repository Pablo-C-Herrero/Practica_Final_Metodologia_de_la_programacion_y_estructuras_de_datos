package juego.objetos;

public class arma extends objeto {

    private int alcance; // El alcance es 1,2 o 3 dependiendo del arma.

    public arma(String nombre, String descripcion) { // Puesde ser espada, escudo, hacha o arco. Y tienen una descripción.
        super(nombre, descripcion, "Arma");
    }

// Setters de los atributos.
    public void setBonusAtaque(int v) { this.bonusAtaque = v; } // Las armas aumentan el ataque base.
    public void setBonusDefensa(int v) { this.bonusDefensa = v; } // El escudo aumenta el ataque base.
    public void setBonusVelocidad(int v) { this.bonusVelocidad = v; } // El arco aumenta la velocidad.

    public void setPenalizacionDefensa(int v) { this.penalizacionDefensa = v; } // El arco da menos protección.
    public void setPenalizacionVelocidad(int v) { this.penalizacionVelocidad = v; } // El hacha pesa mucho.

    // Getter y setter del alcance.
    public void setAlcance(int a) { this.alcance = a; }
    public int getAlcance() { return alcance; }


    public int getBonusAtaque(){
        return bonusAtaque;
    }
}