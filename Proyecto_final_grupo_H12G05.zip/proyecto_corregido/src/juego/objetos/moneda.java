package juego.objetos;

public class moneda extends objeto { // Para comprar la ruta hacia la salida.

    public moneda() {
        super("Moneda", "Sirve como moneda de cambio", "Moneda");
    }
}