package juego.objetos;

public class trampa extends objeto {

    private String efecto; // Dependiendo de la trampa, se hace un efecto u otro.
    // "veneno", "congelacion", "daño"(danio).
    private int dañoPorTurno; // El veneno hace 3 de daño por turno.

    public trampa(String nombre, String descripcion, String efecto) {
        super(nombre, descripcion, "Trampa");
        this.efecto = efecto;
        this.dañoPorTurno = 0;
    }

    // Getters de los atributos.
    public String getEfecto() {
        return efecto;
    }
    public void setDañoPorTurno(int d) {
        this.dañoPorTurno = d;
    }
    public int getDañoPorTurno() {
        return dañoPorTurno;
    }
}