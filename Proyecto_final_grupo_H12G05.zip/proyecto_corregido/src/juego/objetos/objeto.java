package juego.objetos;

public abstract class objeto {

    protected String nombre;
    protected String descripcion;
    protected String tipo;
    protected int bonusAtaque;
    protected int bonusDefensa;
    protected int bonusVelocidad;
    protected int curaVida;
    protected int penalizacionVelocidad;
    protected int penalizacionDefensa;
    protected int duracionTurnos;

    public objeto(String nombre, String descripcion, String tipo) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipo = tipo;
    }

    // Setters y getters de los atributos.
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }

    public int getBonusAtaque() { return bonusAtaque; }
    public int getBonusDefensa() { return bonusDefensa; }
    public int getBonusVelocidad() { return bonusVelocidad; }

    public int getPenalizacionVelocidad() { return penalizacionVelocidad; }
    public int getPenalizacionDefensa() { return penalizacionDefensa; }

    public int getDuracionTurnos() { return duracionTurnos; }

    public String getTipo() { return tipo; }

    // toString.
    public String toString() {
        return nombre + " - " + descripcion;
    }
}