package juego.objetos;

import java.util.Random;

public class creadorObjetos {

    private Random r = new Random(); // Para rabdomizar los bonus de las armas, armaduras y pociones.

    private int rnd(int a, int b) {
        return r.nextInt(b - a + 1) + a;
    }

    public objeto crearObjeto(String nombre) {
        switch (nombre.toLowerCase()) { // Estos son los casos posibles (son todos los objetos que hay).
            case "espada": return crearEspada();
            case "hacha": return crearHacha();
            case "arco": return crearArco();
            case "escudo": return crearEscudo();
            case "yelmo": return crearYelmo();
            case "coraza": return crearCoraza();
            case "grebas": return crearGrebas();
            case "sabaton": return crearSabaton();
            case "curacion": return crearCuracion();
            case "ofensiva": return crearOfensiva();
            case "defensiva": return crearDefensiva();
            case "agil": return crearAgil();
            case "antidoto": return crearAntidoto();
            case "anticongelante": return crearAnti();
            case "llave": return new llave();
            case "moneda": return new moneda();
            case "trampa_veneno": return crearTrampaVeneno();
            case "trampa_congelacion": return crearTrampaCongelacion();
            case "trampa_danio": return crearTrampaDanio();
            default:
                throw new IllegalArgumentException("No existe el objeto: " + nombre);
        }
    }

    // ---------------- POCIONES ----------------

    private pocion crearCuracion() { // Poción sanadora.
        int cura = rnd(15, 35); // Cura entre 15 y 35 de vida.
        pocion p = new pocion("Curación", "Cura " + cura);
        p.setCuraVida(cura);
        p.setDuracionTurnos(1); // Dura el turno que te la tomas.
        return p;
    }

    private pocion crearOfensiva() { // Poción de ataque.
        int bonus = rnd(3, 8); // El daño.
        int turnos = rnd(1, 3); // La duración.
        pocion p = new pocion("Ofensiva",
                "Poción que aumenta el ataque en " + bonus + " durante " + turnos + " turnos de quién la toma.");
        p.setBonusAtaque(bonus);
        p.setDuracionTurnos(turnos);
        return p;
    }

    private pocion crearDefensiva() { // Poción defensiva.
        int bonus = rnd(3, 8); // Defensa.
        int turnos = rnd(1, 3); // Duración.
        pocion p = new pocion("Defensiva",
                "Poción que aumenta la defensa en " + bonus + " durante " + turnos + " turnos de quién la toma.");
        p.setBonusDefensa(bonus);
        p.setDuracionTurnos(turnos);
        return p;
    }


    private pocion crearAgil() { // Poción de movimiento.
        int bonus  = rnd(1, 3); // Movimiento.
        int turnos = rnd(1, 3); // Duración.
        pocion p = new pocion("Ágil",
                "Poción que aumenta la velocidad en " + bonus + " durante " + turnos + " turnos de quién la toma.");
        p.setBonusVelocidad(bonus);
        p.setDuracionTurnos(turnos);
        return p;
    }


    private pocion crearAntidoto() { // Poción antídoto para la trampa venenosa.
        pocion p = new pocion("Antídoto",
                "Poción que quita el efecto de envenenamiento de la trampa venenosa");
        p.setQuitaVeneno(true); // Quita el veneno.
        return p;
    }


    private pocion crearAnti() { // Poción anticongelante para la trampa de congelación.
        pocion p = new pocion("Anticongelante",
                "Poción que quita el efecto de congelamiento de la trampa congelante");
        p.setQuitaCongelacion(true); // Quita el congelado.
        return p;
    }


    // ---------------- ARMAS ----------------

    private arma crearEspada() { // La espada.
        int a = rnd(3, 8); // Ataque.
        arma ar = new arma("Espada", "Espada que aumenta " + a + " el ataque del portador.");
        ar.setBonusAtaque(a);
        ar.setAlcance(1); // 1 de alcance.
        return ar;
    }

    private arma crearHacha() { // Hacha.
        int a = rnd(5, 12); // Ataque.
        int pen = (int) Math.ceil(8.0 / a); // Movimiento que quita.
        arma ar = new arma("Hacha",
                "Arma que aumenta en " + a + " el ataque del portador a cambio de perder " + pen + " velocidad.");
        ar.setBonusAtaque(a);
        ar.setPenalizacionVelocidad(pen);
        ar.setAlcance(2); // 2 de alcance.
        return ar;
    }

    private arma crearArco() { // Arco.
        int a = rnd(3, 8); // Ataque (buff) y defensa (debuff).
        int vel = rnd(1, 3); // Movimiento.
        arma ar = new arma("Arco",
                "Arma que aumenta " + a + " ataque y " + vel + " velocidad al portador a cambio de perder " + a + " defensa.");
        ar.setBonusAtaque(a);
        ar.setBonusVelocidad(vel);
        ar.setPenalizacionDefensa(a);
        ar.setAlcance(3); // 3 de alcance.
        return ar;
    }

    private arma crearEscudo() { // Escudo.
        int d = rnd(4, 10); // Defensa.
        arma ar = new arma("Escudo", "Escudo que aumenta " + d + " la defensa del portador.");
        ar.setBonusDefensa(d);
        ar.setAlcance(0); // Solo es para cuando te atacan.
        return ar;
    }


    // ---------------- ARMADURA ----------------

    private armadura crearYelmo() { // Yelmo.
        int b = rnd(2, 5); // Defensa.
        armadura a = new armadura("Yelmo", "Yelmo que aumenta " + b + " la defensa del portador.");
        a.setBonusDefensa(b);
        return a;
    }

    private armadura crearCoraza() { // Coraza.
        int b = rnd(4, 8); // Defensa.
        armadura a = new armadura("Coraza", "Coraza que aumenta " + b + " la defensa del portador.");
        a.setBonusDefensa(b);
        return a;
    }

    private armadura crearGrebas() { // Grebas.
        int bd = rnd(2, 5); // Defensa.
        int pv = rnd(1, 2); // Debuff movimiento.
        armadura a = new armadura("Grebas",
                "Grebas que aumentan " + bd + " la defensa pero reducen " + pv + " la velocidad del portador.");
        a.setBonusDefensa(bd);
        a.setPenalizacionVelocidad(pv);
        return a;
    }

    private armadura crearSabaton() { // Sabatón.
        int bv = rnd(1, 2); // Movimiento (buff).
        armadura a = new armadura("Sabaton", "Sabaton que aumenta " + bv + " la velocidad del portador.");
        a.setBonusVelocidad(bv);
        return a;
    }


    // ---------------- TRAMPAS ----------------

    private trampa crearTrampaVeneno() { // Trampa venenosa.
        trampa t = new trampa("Trampa de veneno", "Envenena al jugador", "veneno");
        t.setDañoPorTurno(3); // Hace 3 de daño por turno.
        return t;
    }

    private trampa crearTrampaCongelacion() { // Trampa de congelación.
        return new trampa("Trampa de hielo", "Reduce velocidad del jugador", "congelacion");
    }

    private trampa crearTrampaDanio() { // Trampa de daño.
        trampa t = new trampa("Trampa explosiva", "Hace 10 de daño", "danio");
        t.setDañoPorTurno(10); // Hace al caer en ella 10 de daño al jugador.
        return t;
    }
}
