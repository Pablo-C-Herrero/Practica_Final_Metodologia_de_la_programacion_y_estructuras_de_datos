package juego.Test_JUnit.Personajes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class inventarioTest {

    @Test
    void add() {
    }

    @Test
    void get() {
    }

    @Test
    void remove() {
    }

    @Test
    void getSize() {
    }

    @Test
    void isEmpty() {
    }

    @Test
    void getLista() {
    }
}