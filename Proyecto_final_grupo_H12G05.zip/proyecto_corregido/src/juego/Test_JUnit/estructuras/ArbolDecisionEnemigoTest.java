package juego.Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ArbolDecisionEnemigoTest {

    @Test
    void ejecutar() {
    }
}