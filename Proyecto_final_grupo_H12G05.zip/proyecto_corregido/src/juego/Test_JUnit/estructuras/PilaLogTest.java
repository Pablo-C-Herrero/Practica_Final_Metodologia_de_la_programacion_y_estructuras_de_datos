package juego.Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PilaLogTest {

    @Test
    void push() {
    }

    @Test
    void pop() {
    }

    @Test
    void peek() {
    }

    @Test
    void isEmpty() {
    }

    @Test
    void getSize() {
    }

    @Test
    void vaciarMostrandoHistorial() {
    }

    @Test
    void obtenerHistorialComoTexto() {
    }
}