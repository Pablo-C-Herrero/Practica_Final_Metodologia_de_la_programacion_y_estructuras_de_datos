package juego.Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Lista_CDETest {

    @Test
    void add() {
    }

    @Test
    void testAdd() {
    }

    @Test
    void remove() {
    }

    @Test
    void testRemove() {
    }

    @Test
    void get() {
    }

    @Test
    void getIndex() {
    }

    @Test
    void contiene() {
    }

    @Test
    void getSize() {
    }

    @Test
    void isEmpty() {
    }
}