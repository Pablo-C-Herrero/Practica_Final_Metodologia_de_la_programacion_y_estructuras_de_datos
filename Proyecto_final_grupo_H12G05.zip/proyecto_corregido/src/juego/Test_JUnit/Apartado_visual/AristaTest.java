package juego.Test_JUnit.Apartado_visual;

import static org.junit.jupiter.api.Assertions.*;
import juego.Apartado_visual.EstructurasUtilizadas.Arista;

public class AristaTest {

    @org.junit.jupiter.api.Test
    void getOrigen() {
    }

    @org.junit.jupiter.api.Test
    void getDestino() {
    }

    @org.junit.jupiter.api.Test
    void getCoste() {
    }

    @org.junit.jupiter.api.Test
    void compareTo() {
    }

}
