package juego.Test_JUnit.Apartado_visual;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import juego.Apartado_visual.EstructurasUtilizadas.Vertice;

class VerticeTest {

    @Test
    void addArista() {
    }

    @Test
    void addAristaSalida() {
    }

    @Test
    void addAristaEntrada() {
    }

    @Test
    void getGrado() {
    }

    @Test
    void getData() {
    }

    @Test
    void compareTo() {
    }
}