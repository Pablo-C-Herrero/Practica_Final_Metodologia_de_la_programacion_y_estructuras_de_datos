package juego.Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class pocionTest {

    @Test
    void setQuitaVeneno() {
    }

    @Test
    void setQuitaCongelacion() {
    }

    @Test
    void quitaVeneno() {
    }

    @Test
    void quitaCongelacion() {
    }

    @Test
    void setBonusAtaque() {
    }

    @Test
    void setBonusDefensa() {
    }

    @Test
    void setBonusVelocidad() {
    }

    @Test
    void getBonusAtaque() {
    }

    @Test
    void getBonusDefensa() {
    }

    @Test
    void getBonusVelocidad() {
    }

    @Test
    void setDuracionTurnos() {
    }

    @Test
    void getDuracionTurnos() {
    }

    @Test
    void setCuraVida() {
    }

    @Test
    void getCuraVida() {
    }
}