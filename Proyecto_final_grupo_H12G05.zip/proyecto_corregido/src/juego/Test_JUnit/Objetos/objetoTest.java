package juego.Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class objetoTest {

    @Test
    void getNombre() {
    }

    @Test
    void getDescripcion() {
    }

    @Test
    void getBonusAtaque() {
    }

    @Test
    void getBonusDefensa() {
    }

    @Test
    void getBonusVelocidad() {
    }

    @Test
    void getPenalizacionVelocidad() {
    }

    @Test
    void getPenalizacionDefensa() {
    }

    @Test
    void getDuracionTurnos() {
    }

    @Test
    void getTipo() {
    }

    @Test
    void testToString() {
    }
}