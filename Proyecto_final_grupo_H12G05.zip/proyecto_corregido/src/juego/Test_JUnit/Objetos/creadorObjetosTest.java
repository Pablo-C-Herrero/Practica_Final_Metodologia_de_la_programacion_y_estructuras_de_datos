package juego.Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class creadorObjetosTest {

    @Test
    void crearObjeto() {
    }
}