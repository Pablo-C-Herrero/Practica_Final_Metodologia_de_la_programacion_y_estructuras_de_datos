package juego.Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class armaduraTest {

    @Test
    void setBonusDefensa() {
    }

    @Test
    void setBonusVelocidad() {
    }

    @Test
    void setPenalizacionVelocidad() {
    }

    @Test
    void getBonusDefensa() {
    }
}