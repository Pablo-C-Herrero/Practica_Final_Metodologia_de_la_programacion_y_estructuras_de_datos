package juego.Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class armaTest {

    @Test
    void setBonusAtaque() {
    }

    @Test
    void setBonusDefensa() {
    }

    @Test
    void setBonusVelocidad() {
    }

    @Test
    void setPenalizacionDefensa() {
    }

    @Test
    void setPenalizacionVelocidad() {
    }

    @Test
    void setAlcance() {
    }

    @Test
    void getAlcance() {
    }

    @Test
    void getBonusAtaque() {
    }
}