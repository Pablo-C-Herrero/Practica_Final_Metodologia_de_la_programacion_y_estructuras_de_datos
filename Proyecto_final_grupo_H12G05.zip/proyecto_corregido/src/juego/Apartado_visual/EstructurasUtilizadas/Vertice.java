package juego.Apartado_visual.EstructurasUtilizadas;

public class Vertice<T> implements Comparable<Vertice<T>> {

    T data;
    public ListaSimplementeEnlazada<Arista<T>> aristasSimples;
    public ListaSimplementeEnlazada<Arista<T>> aristasEntrada;
    public ListaSimplementeEnlazada<Arista<T>> aristasSalida;
    public int grado;

    public Vertice(T data) {
        this.data           = data;
        this.aristasSimples = new ListaSimplementeEnlazada<>();
        this.aristasEntrada = new ListaSimplementeEnlazada<>();
        this.aristasSalida  = new ListaSimplementeEnlazada<>();
        grado = 0;
    }

    public void addArista(Arista<T> arista) { // Metodo para añadir una arista al grafo.
        if (arista.origen == this || arista.destino == this) {
            this.aristasSimples.add(arista);
            grado++;
        } else {
            System.out.println("No se pudo añadir la arista; ninguno de los extremos corresponde con este vértice");
        }
    }

    public void addAristaSalida(Arista<T> arista) { // Metodo para añadir una arista a la lista de aristas de salida.
        if (arista.origen == this) {
            this.aristasSalida.add(arista);
            grado++;
        } else {
            System.out.println("No se pudo añadir la arista de salida; el origen no corresponde con este vértice");
        }
    }

    public void addAristaEntrada(Arista<T> arista) { // Metodo para añadir una arista a la lista de aristas de entrada.
        if (arista.destino == this) {
            this.aristasEntrada.add(arista);
            grado++;
        } else {
            System.out.println("No se pudo añadir la arista de entrada; el destino no corresponde con este vértice");
        }
    }

    public int  getGrado() { return grado; }
    public T    getData()  { return data;  }

    @Override
    public int compareTo(Vertice<T> o) {
        return (this == o) ? 0 : 1;
    }
}
