package juego.Apartado_visual.EstructurasUtilizadas;

// FIX M3: clase y campos públicos para que sean accesibles desde otros paquetes.
public class ElementoSE<T>{
    public T dato;
    public ElementoSE<T> siguiente;

    public ElementoSE(T dato){
        this.dato = dato;
        this.siguiente = null;
    }
}
