package juego.Apartado_visual.EstructurasUtilizadas;

// FIX M3: clase y campos públicos para que sean accesibles desde otros paquetes.
public class ElementoLC<T>{
    public T dato;
    public ElementoLC<T> siguiente;

    public ElementoLC(T dato){
        this.dato = dato;
        this.siguiente = null;
    }
}
