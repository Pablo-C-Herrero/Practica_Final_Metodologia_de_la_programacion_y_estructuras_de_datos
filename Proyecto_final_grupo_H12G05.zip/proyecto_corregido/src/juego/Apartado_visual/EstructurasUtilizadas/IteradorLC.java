package juego.Apartado_visual.EstructurasUtilizadas;

public class IteradorLC<T> implements MiIterador<T>{
    private ElementoLC<T> actual;

    public IteradorLC(ElementoLC<T> start){
        this.actual = start;
    }

    @Override
    public boolean hasNext(){
        return actual != null;
    }

    @Override
    public T next(){ // Se va avanzando.
        if (!hasNext()) return null;
        T dato = actual.dato;
        actual = actual.siguiente;
        return dato;
    }
}
