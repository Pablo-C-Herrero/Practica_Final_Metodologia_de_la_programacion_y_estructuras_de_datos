package juego.Apartado_visual.EstructurasUtilizadas;

public class ListaSimplementeEnlazada<T extends Comparable<T>> implements Lista<T>, Comparable<ListaSimplementeEnlazada<T>> {
    protected ElementoSE<T> primero;

    @Override
    public void add(T dato){ // Metodo para añadir un elemento a la lista.
        ElementoSE<T> elemento = new ElementoSE<>(dato);
        if (isEmpty()) primero = elemento;
        else{
            ElementoSE<T> aux = primero;
            while (aux.siguiente != null) aux = aux.siguiente; // Se avanza para ponerlo al final.
            aux.siguiente = elemento;
        }
    }

    @Override
    public T get(T dato){ // Metodo para obtener la información del elemento dato.
        ElementoSE<T> aux = primero;
        while (aux != null){ // Se avanza hasta que el dato coincida.
            if (aux.dato.compareTo(dato) == 0) return aux.dato;
            aux = aux.siguiente;
        }
        return null;
    }

    @Override
    public T del(T dato){ // Metodo para eliminar un elemento de la lista.
        ElementoSE<T> act = primero, ant = null;
        while (act != null){ // Se avanza hasta que coincida, y se elimina.
            if (act.dato.compareTo(dato) == 0){
                if (ant == null) primero = act.siguiente;
                else ant.siguiente = act.siguiente;
                return act.dato;
            }
            ant = act;
            act = act.siguiente;
        }
        return null;
    }

    @Override
    public boolean isEmpty(){
        return primero == null;
    }

    @Override
    public int size(){ // Metodo para ver el tamaño de la lista.
        int size = 0;
        if (!isEmpty()){ // Se recorre y se añade 1 hasta que se acabe.
            size++;
            ElementoSE<T> aux = primero;
            while (aux.siguiente != null){
                size++;
                aux = aux.siguiente;
            }
        }
        return size;
    }

    @Override
    public MiIterador<T> getIterador(){
        return new IteradorLSE<>(this.primero);
    }

    @Override
    public T findElement(int pos){
        if (!isEmpty() && pos < size()){
            ElementoSE<T> aux = this.primero;
            for (int i = 0; i < pos; i++){
                aux = aux.siguiente;
            }
            return aux.dato;
        }
        return null;
    }

    @Override
    public int findPosition(T dato){
        if (!isEmpty()){
            ElementoSE<T> aux = this.primero;
            MiIterador<T> it = getIterador();
            int position = 0;
            do{
                if (aux.dato.compareTo(dato) == 0) return position;
                aux = aux.siguiente;
                position++;
                it.next();
            }while(it.hasNext());
        }
        return -1;
    }

    @Override
    public int compareTo(ListaSimplementeEnlazada<T> o) {
        return 0;
    }
}
