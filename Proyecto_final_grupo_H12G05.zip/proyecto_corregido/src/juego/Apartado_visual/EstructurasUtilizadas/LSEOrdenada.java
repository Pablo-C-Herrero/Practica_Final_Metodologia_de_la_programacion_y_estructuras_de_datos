package juego.Apartado_visual.EstructurasUtilizadas;

public class LSEOrdenada<T extends Comparable<T>> extends ListaSimplementeEnlazada<T> {

    @Override
    public void add(T dato) { // Metodo para añadir el elemento a la lista.
        ElementoSE<T> nuevo = new ElementoSE<>(dato);
        if (primero == null || primero.dato.compareTo(dato) > 0) { // Si está vacío se coloca.
            nuevo.siguiente = primero;
            primero = nuevo;
        } else { // Si hay, al menos, un elemento.
            ElementoSE<T> act = primero;
            while (act.siguiente != null && act.siguiente.dato.compareTo(dato) <= 0) { // Si el siguiente existe.
                act = act.siguiente; // Se avanza.
            }
            nuevo.siguiente = act.siguiente;
            act.siguiente = nuevo;
        }
    }

    @Override
    public T get(T dato){ // Metodo para obtener la información de un elemento.
        ElementoSE<T> aux = primero;
        while (aux != null){ // Se busca avanzando por la lista.
            if (aux.dato.compareTo(dato) == 0) return aux.dato;
            aux = aux.siguiente;
        }
        return null;
    }

    @Override
    public T del(T dato){ // Metodo para eliminar un elemento de la lista.
        ElementoSE<T> act = primero, ant = null;
        while (act != null){ // Se recorre y cuando se encuentra, se elimina.
            if (act.dato.compareTo(dato) == 0){
                if (ant == null) primero = act.siguiente;
                else ant.siguiente = act.siguiente;
                return act.dato;
            }
            ant = act;
            act = act.siguiente;
        }
        return null;
    }

    @Override
    public boolean isEmpty(){
        return primero == null;
    }

    @Override
    public int size(){ // Metodo para ver el tamaño de la lista.
        int size = 0;
        ElementoSE<T> aux = primero;
        while (aux != null){ // Se avanza y se añade 1 cada vez que se avance.
            size++;
            aux = aux.siguiente;
        }
        return size;
    }

    @Override
    public MiIterador<T> getIterador(){
        return new IteradorLSE<>(this.primero);
    }

    @Override
    public T findElement(int pos){ // Metodo para hallar qué elemento está en la posición pos.
        if (!isEmpty() && pos < size()){ // Se recorre hasta que la posición sea la que se busca y se ve lo que hay ahí.
            ElementoSE<T> aux = this.primero;
            for (int i = 0; i < pos; i++){
                aux = aux.siguiente;
            }
            return aux.dato;
        }
        return null;
    }

    @Override
    public int findPosition(T dato){ // Metodo para saber en qué posición está el elemento dato.
        if (!isEmpty()){
            ElementoSE<T> aux = this.primero;
            int position = 0;
            while (aux != null){ // Se avanza hasta que el elemento sea el que se busca, y se retorna la posición.
                if (aux.dato.compareTo(dato) == 0) return position;
                aux = aux.siguiente;
                position++;
            }
        }
        return -1;
    }
}
