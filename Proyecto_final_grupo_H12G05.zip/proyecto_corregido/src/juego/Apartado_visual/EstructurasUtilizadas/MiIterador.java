package juego.Apartado_visual.EstructurasUtilizadas;

public interface MiIterador<T>{
    boolean hasNext();
    T next();
}
