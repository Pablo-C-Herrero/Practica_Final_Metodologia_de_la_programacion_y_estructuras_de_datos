package juego.Apartado_visual.EstructurasUtilizadas;

public class Arista<T> implements Comparable<Arista<T>> {

    Vertice<T> origen;
    Vertice<T> destino;
    double     coste;

    public Arista(Vertice<T> origen, Vertice<T> destino, double coste) {
        this.origen  = origen;
        this.destino = destino;
        this.coste   = coste;
    }

    // Getters.
    public Vertice<T> getOrigen()  { return origen;  }
    public Vertice<T> getDestino() { return destino; }
    public double     getCoste()   { return coste;   }

    @Override
    public int compareTo(Arista<T> o) {
        int cmp = Double.compare(this.coste, o.coste);
        return (cmp != 0) ? cmp : (this == o ? 0 : 1);
    }
}
