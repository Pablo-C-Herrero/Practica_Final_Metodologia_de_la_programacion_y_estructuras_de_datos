package juego.Apartado_visual.EstructurasUtilizadas;

public class ListaCircular<T extends Comparable<T>> implements Lista<T>{
    protected ElementoLC<T> primero;

    @Override
    public void add(T dato){ // Metodo para añadir un elemento a la lista.
        ElementoLC<T> elemento = new ElementoLC<>(dato);
        if (isEmpty()){
            primero = elemento;
            primero.siguiente = primero;
        } else {
            ElementoLC<T> aux = primero;
            while (aux.siguiente != primero) aux = aux.siguiente; // Se recorre y se añade al final.
            aux.siguiente = elemento;
            elemento.siguiente = primero;
        }
    }

    @Override
    public T get(T dato){ // Metodo para obrtener los datos de un elemento de la lista.
        if (isEmpty()) return null;
        ElementoLC<T> aux = primero;
        do {
            if (aux.dato.compareTo(dato) == 0) return aux.dato;
            aux = aux.siguiente;
        } while (aux != primero);
        return null;
    }

    @Override
    public T del(T dato){ // Metodo para eliminar un elemento de la lista.
        if (isEmpty()) return null;
        ElementoLC<T> act = primero, ant = null;
        do {
            if (act.dato.compareTo(dato) == 0){
                if (size() == 1){
                    primero = null;
                } else {
                    if (ant == null){
                        // Eliminar el primero: necesitamos el último para cerrar el círculo
                        ElementoLC<T> ultimo = primero;
                        while (ultimo.siguiente != primero) ultimo = ultimo.siguiente;
                        primero = act.siguiente;
                        ultimo.siguiente = primero;
                    } else {
                        ant.siguiente = act.siguiente;
                    }
                }
                return act.dato;
            }
            ant = act;
            act = act.siguiente;
        } while (act != primero);
        return null;
    }

    @Override
    public boolean isEmpty(){
        return primero == null;
    }

    @Override
    public int size(){ // Metodo para saber el tamaño que tiene la lista.
        if (isEmpty()) return 0;
        int count = 1;
        ElementoLC<T> aux = primero;
        while (aux.siguiente != primero){
            count++;
            aux = aux.siguiente;
        }
        return count;
    }

    @Override
    public MiIterador<T> getIterador(){
        return new IteradorLC<>(this.primero);
    }

    @Override
    public T findElement(int pos){ // Se obtiene el elemento que está en la posición pos.
        if (isEmpty()) return null;
        int s = size();
        pos = ((pos % s) + s) % s;
        ElementoLC<T> aux = primero;
        for (int i = 0; i < pos; i++) aux = aux.siguiente;
        return aux.dato;
    }

    @Override
    public int findPosition(T dato){ // Metodo para obtener la posición de un elemento de la lista.
        if (isEmpty()) return -1;
        ElementoLC<T> aux = primero;
        int position = 0;
        int s = size();
        for (int i = 0; i < s; i++){
            if (aux.dato.compareTo(dato) == 0) return position;
            aux = aux.siguiente;
            position++;
        }
        return -1;
    }
}
