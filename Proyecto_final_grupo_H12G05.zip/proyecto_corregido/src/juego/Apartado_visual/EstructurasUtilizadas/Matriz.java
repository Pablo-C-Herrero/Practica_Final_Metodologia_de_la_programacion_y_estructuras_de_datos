package juego.Apartado_visual.EstructurasUtilizadas;

/**
 0  = vacío
 1  = jugador
 2  = tesoro
 3  = trampa
 4  = enemigo débil
 5  = enemigo fuerte
 6  = puerta de salida sin llave
 7  = puerta de salida con llave
 8  = puerta de llegada (spawn del jugador al entrar)
 9  = salida final del juego (victoria al atravesarla)
 */

public class Matriz implements Comparable<Matriz> {

    protected ListaSimplementeEnlazada<ListaSimplementeEnlazada<Integer>> matrizFormatoLista;
    private final int filas;
    private final int columnas;

    public Matriz(int filas, int columnas) { // Metodo para crear la matriz n*m.
        this.filas = filas;
        this.columnas = columnas;
        ListaSimplementeEnlazada<ListaSimplementeEnlazada<Integer>> matriz = new ListaSimplementeEnlazada<>();
        for (int m = 0; m < filas; m++) { // Cada fila es una lista.
            ListaSimplementeEnlazada<Integer> fila = new ListaSimplementeEnlazada<>();
            for (int n = 0; n < columnas; n++) fila.add(0); // Cada columna está en una fila.
            matriz.add(fila);
        }
        this.matrizFormatoLista = matriz;
    }

    public int getFilas()    { return filas;    }
    public int getColumnas() { return columnas; }

    public ListaSimplementeEnlazada<ListaSimplementeEnlazada<Integer>> getMatrizFormatoLista() {
        return matrizFormatoLista;
    }

    public int getCelda(int fila, int col) { // Metodo para saber lo que hay en una celda determinada.
        if (fila < 0 || fila >= filas || col < 0 || col >= columnas) return -1;
        ListaSimplementeEnlazada<Integer> filaLista = matrizFormatoLista.findElement(fila);
        if (filaLista == null) return -1;
        Integer val = filaLista.findElement(col);
        return (val == null) ? -1 : val;
    }

    public void setCelda(int fila, int col, int valor) { // Cambiar lo que hay en la celda.
        if (fila < 0 || fila >= filas || col < 0 || col >= columnas) return;
        ListaSimplementeEnlazada<Integer> filaAntigua = matrizFormatoLista.findElement(fila);
        if (filaAntigua == null) return;

        ListaSimplementeEnlazada<Integer> filaNueva = new ListaSimplementeEnlazada<>();
        for (int k = 0; k < columnas; k++) { // Se crea la nueva fila modificada.
            Integer v = filaAntigua.findElement(k);
            filaNueva.add(k == col ? valor : (v == null ? 0 : v));
        }

        ListaSimplementeEnlazada<ListaSimplementeEnlazada<Integer>> nuevaMatriz =
                new ListaSimplementeEnlazada<>();
        for (int m = 0; m < filas; m++) { // Es la nueva matriz fila por fila.
            nuevaMatriz.add(m == fila ? filaNueva : matrizFormatoLista.findElement(m));
        }
        this.matrizFormatoLista = nuevaMatriz;
    }

    public int[] buscarCelda(int valor) { // Metodo para buscar la celda con el valor valor.
        for (int f = 0; f < filas; f++) {
            ListaSimplementeEnlazada<Integer> filaLista = matrizFormatoLista.findElement(f);
            if (filaLista == null) continue;
            for (int c = 0; c < columnas; c++) {
                Integer v = filaLista.findElement(c);
                if (v != null && v == valor) return new int[]{f, c};
            }
        }
        return new int[]{-1, -1};
    }

    @Override
    public int compareTo(Matriz o) {
        return (this == o) ? 0 : 1;
    }
}
