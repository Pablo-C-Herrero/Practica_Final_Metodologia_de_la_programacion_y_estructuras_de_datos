package juego.Apartado_visual;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PantallaTituloController {

    @FXML private Button salirButton; // Declara el botón para salir del juego.

    @FXML
    protected void onJugarButtonClick() { // Métdo para entrar a jugar.
        try { // Bloque try.
            FXMLLoader fxmlLoader = new FXMLLoader( // Cargador de archivos FXML.
                    PracticaFinal.class.getResource("/juego/Apartado_visual/game-view.fxml")); // Se busca el archivo.
            Stage jugar = new Stage(); // Crea la ventana de juego.
            Scene scene = new Scene(fxmlLoader.load(), 1100, 700); // Tamaño.
            jugar.setTitle("Dungeon RPG");
            jugar.setScene(scene); // Escenario.
            jugar.show(); // La pantalla.
            onSalirButtonClick(); // Cerrar pantalla de título.
        } catch (Exception e) { // Se captura el error que pueda haber.
            e.printStackTrace();
        }
    }

    @FXML
    protected void onSalirButtonClick() { // Metodo para salir del juego.
        Stage stage = (Stage) salirButton.getScene().getWindow();
        stage.close();
    }
}
