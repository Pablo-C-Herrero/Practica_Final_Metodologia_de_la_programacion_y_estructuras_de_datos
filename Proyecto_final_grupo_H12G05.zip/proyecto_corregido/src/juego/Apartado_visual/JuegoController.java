package juego.Apartado_visual;

import juego.Apartado_visual.EstructurasUtilizadas.*;
import juego.personajes.jugador;
import juego.personajes.enemigo;
import juego.objetos.*;
import juego.turnos.turnos;
import juego.estructuras.Lista_CDE.Lista_CDE;
import juego.estructuras.Pila.PilaLog;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.input.KeyEvent;

import java.util.Random;

/**
 * Valores que puede tomar cada elemento de la celda de la matriz:
 *   0 = vacío         1 = jugador
 *   2 = tesoro        3 = trampa
 *   4 = enemigo débil 5 = enemigo fuerte
 *   6 = puerta salida sin llave
 *   7 = puerta salida con llave
 *   8 = puerta de llegada (spawn)
 *   9 = salida final (victoria)
 *
 * FASES DEL TURNO DEL JUGADOR: MOVIMIENTO → INVENTARIO → ACCIÓN
 */
public class JuegoController {


    // FXML — barra de stats
    @FXML private Label labelVida;
    @FXML private Label labelAtaque;
    @FXML private Label labelDefensa;
    @FXML private Label labelVelocidad;
    @FXML private Label labelMovimientos;


    // FXML — grid y mensajes
    @FXML private GridPane gridHabitacion;
    @FXML private Label    labelMensajes;


    // FXML — botones de fase
    @FXML private Button botonSaltarTurno;
    @FXML private Button botonMoverse;
    @FXML private Button botonInventario;
    @FXML private Button botonAccion;


    // FXML — inventario y equipamiento (panel lateral)
    @FXML private ListView<String> listaInventario;
    @FXML private Label labelEquipoArma;
    @FXML private Label labelEquipoEscudo;
    @FXML private Label labelEquipoYelmo;
    @FXML private Label labelEquipoCoraza;
    @FXML private Label labelEquipoGrebas;
    @FXML private Label labelEquipoSabaton;


    // FXML — info de ruta (se activa al comprar con monedas)
    @FXML private Label labelRuta;


    // Lógica del juego
    private jugador        jugadorObj;
    private enemigo[]      enemigosActuales;
    private turnos         gestorTurnos;
    private creadorObjetos creador = new creadorObjetos();
    private Random         rng     = new Random();

    // PilaLog para el historial de partida
    private PilaLog<String> logPartida = new PilaLog<>();

    // Grafo de habitaciones
    private Grafo<Matriz>   mapaJuego;
    private Vertice<Matriz> habitacionActual;
    private Vertice<Matriz> habitacionFinal;

    // Control de fases del turno
    private enum FaseTurno { MOVIMIENTO, INVENTARIO, ACCION, ESPERA_ENEMIGOS }
    private FaseTurno faseActual = FaseTurno.MOVIMIENTO;

    private char   teclaMovimiento = 0;
    private String bufferCantidad  = "";

    private boolean rutaComprada = false;
    private int indiceInventarioSeleccionado = -1;
    private boolean venenoAplicadoEsteTurno = false;


    // Inicialización JavaFX
    @FXML
    public void initialize() { // Es auntomático al cargar el FXML.
        jugadorObj      = new jugador(); // Se crea el jugador, el mapa, y la sala inicial.
        mapaJuego       = crearMapa();
        habitacionFinal = mapaJuego.getVertices().findElement(mapaJuego.getVertices().size() - 1);

        habitacionActual = mapaJuego.getVertices().findElement(0);
        int[] spawn = habitacionActual.getData().buscarCelda(8); // Se coloca al jugador en la celda 8.
        if (spawn[0] != -1) { // Si no se encuentra.
            jugadorObj.setPosicion(spawn[0], spawn[1]); // Pone al jugador en (0,1).
            habitacionActual.getData().setCelda(spawn[0], spawn[1], 1); // Se coloca al jugador en el (1,1).
        } else { // Si no hay spawn.
            Matriz m = habitacionActual.getData(); // La matriz se guarda.
            int cf = m.getFilas() / 2, cc = m.getColumnas() / 2;
            jugadorObj.setPosicion(cf, cc); // Se pone al jugador en el centro.
            m.setCelda(cf, cc, 1);
        }

        iniciarSala(); // Se generan las trampas, los tesoros, y los enemigos.
        actualizarGrid(); // Se actualiza la interfaz.
        actualizarStats();
        actualizarInventarioUI();

        gridHabitacion.setFocusTraversable(true);
        gridHabitacion.setOnKeyPressed(this::manejarTecla); // Para moverse.

        aplicarVenenoInicioTurno();
    }


    // Creación del mapa (grafo de habitaciones)
    @SuppressWarnings("unchecked")
    private Grafo<Matriz> crearMapa() { // Se generan todas las habitaciones.
        Vertice<Matriz>[] Vext = new Vertice[20];
        Grafo<Matriz> g = new Grafo<>();
        for (int i = 1; i <= 19; i++){ // Se crean las salas.
            Vext[i] = new Vertice<>(new Matriz(7, 13));
            g.addVertice(Vext[i]); // Se añade el vértice.
        }
        for (int i = 1; i < 19; i++){ // Se unen las 19 salas.
            Arista<Matriz> arista = new Arista<>(Vext[i], Vext[i+1], 1);
            g.addArista(arista); // Se crea el recorrido.
        }

        int total = g.getVertices().size();
        for (int i = 0; i < total; i++) { // Se recorren las slas.
            Vertice<Matriz> v = g.getVertices().findElement(i);
            Matriz m = v.getData(); // Se saca la matriz.
            int sf = m.getFilas() / 2;
            int sc = m.getColumnas() / 2;
            m.setCelda(sf, sc, 8);

            if (i < total - 1){ // Si no es la última sala.
                int valor = 6; // Puerta normal.
                int tipoPuerta = rng.nextInt(5);
                if (tipoPuerta == 4) valor = 7;
                m.setCelda(sf, m.getColumnas() - 1, valor); // Se coloca a la derecha.
            }
            else m.setCelda(sf, m.getColumnas() - 1, 9); // Si es la última sala, es la salida final.
        }
        return g;
    }


    // Iniciar sala: crear enemigos, tesoros y trampas
    private void iniciarSala() {
        Matriz m = habitacionActual.getData(); // Matriz actual.

        int numEnemigos = rng.nextInt(3); // Se crean los enemigos.
        enemigosActuales = new enemigo[numEnemigos];
        ListaSimplementeEnlazada<Vertice<Matriz>> listaVertices = mapaJuego.getVertices();
        int numeroHabitacion = listaVertices.findPosition(habitacionActual);
        for (int i = 0; i < numEnemigos; i++) { // Se recorren los enemigos.
            String tipo = "debil"; // Es débil
            int tipoEnemigo = rng.nextInt(10);
            if (numeroHabitacion < 10){ //Hasta la sala 10.
                if (tipoEnemigo == 9) tipo = "fuerte"; // Si el valor random es 9 es enemigo fuerte en vez de débil.
            }
            else if (numeroHabitacion < 18) { //A partir de la sala 10.
                if(tipoEnemigo < 7) tipo = "fuerte"; // El 70% son fuertes.
            }
            else if (tipoEnemigo < 4) tipo = "fuerte";
            enemigosActuales[i] = new enemigo(tipo, jugadorObj); // Se crea el enemigo.
            int[] pos = celdaVaciaAleatoria(m); // Se coloca en una casilla vacía cualquiera.
            if (pos[0] != -1) {
                enemigosActuales[i].setPosicion(pos[0], pos[1]);
                m.setCelda(pos[0], pos[1], tipo.equals("debil") ? 4 : 5);
            }
            // Inyectar predicado de colisión al enemigo
            final int idx = i;
            enemigosActuales[i].setCeldaLibre((f, c) -> celdaLibreParaEnemigo(f, c, idx));
        }

        int nTesoros = 1 + rng.nextInt(2); // Se crean los tesoros.
        for (int i = 0; i < nTesoros; i++) {
            int[] pos = celdaVaciaAleatoria(m); // Se ponen en una casilla vacía.
            if (pos[0] != -1) m.setCelda(pos[0], pos[1], 2);
        }

        int nTrampas = 1 + rng.nextInt(2); // Se crean las trampas.
        for (int i = 0; i < nTrampas; i++) {
            int[] pos = celdaVaciaAleatoria(m); // Se ponen en una casilla vacía.
            if (pos[0] != -1) m.setCelda(pos[0], pos[1], 3);
        }

        gestorTurnos                 = new turnos(jugadorObj, enemigosActuales);
        gestorTurnos.iniciarRonda();
        faseActual                   = FaseTurno.MOVIMIENTO;
        rutaComprada                 = false;
        venenoAplicadoEsteTurno      = false;
        indiceInventarioSeleccionado = -1;

        log("Entraste en una nueva sala. ¡Cuidado!");
    }

    /**
     * Devuelve true si la celda (f, c) está libre para que el enemigo de índice
     * `ignorarIdx` se mueva a ella (no está ocupada por el jugador ni por otro
     * enemigo vivo distinto).
     */
    private boolean celdaLibreParaEnemigo(int f, int c, int ignorarIdx) {
        Matriz m = habitacionActual.getData();
        int val = m.getCelda(f, c);
        return val == 0;
    }


    // Veneno al inicio del turno
    private void aplicarVenenoInicioTurno() { // Se le hace 3 de daño al jugador antes de moverse si está envenenado.
        if (jugadorObj.tieneVeneno() && !venenoAplicadoEsteTurno) {
            jugadorObj.recibirDaño(3);
            venenoAplicadoEsteTurno = true;
            log("☠ Veneno: recibes 3 de daño al inicio del turno. Vida: " + jugadorObj.getVida());
            actualizarStats();
            comprobarMuerte();
        }
    }


    // Manejo de teclas (movimiento: w/a/s/d + número + Enter)
    private void manejarTecla(KeyEvent e) {
        if (faseActual != FaseTurno.MOVIMIENTO) return;

        String texto = e.getText().toLowerCase();

        if (texto.equals("w") || texto.equals("a")
                || texto.equals("s") || texto.equals("d")) {
            teclaMovimiento = texto.charAt(0);
            bufferCantidad  = "";
            log("Dirección: " + texto.toUpperCase()
                    + " — introduce cuántos pasos (1-" + jugadorObj.getVelocidad() + ") y pulsa Enter.");
            return;
        }

        if (teclaMovimiento != 0 && texto.matches("[0-9]")) {
            bufferCantidad += texto;
            return;
        }

        if (teclaMovimiento != 0 && e.getCode().getName().equals("Enter")) {
            int pasos;
            try {
                pasos = Integer.parseInt(bufferCantidad);
            } catch (NumberFormatException ex) {
                pasos = 1;
            }
            if (pasos <= 0) pasos = 1;
            if (pasos > jugadorObj.getVelocidad()) pasos = jugadorObj.getVelocidad();

            ejecutarMovimiento(teclaMovimiento, pasos);
            teclaMovimiento = 0;
            bufferCantidad  = "";
        }
    }


    // Ejecutar movimiento del jugador
    private void ejecutarMovimiento(char direccion, int pasos) {
        Matriz m = habitacionActual.getData();
        int fila = jugadorObj.getFila();
        int col = jugadorObj.getColumna();

        int dFila = 0, dCol = 0;
        switch (direccion) {
            case 'w' -> dFila = -1;
            case 's' -> dFila = 1;
            case 'a' -> dCol = -1;
            case 'd' -> dCol = 1;
        }

        int nuevaFila = Math.max(0, Math.min(fila + dFila * pasos, m.getFilas() - 1));
        int nuevaCol = Math.max(0, Math.min(col + dCol * pasos, m.getColumnas() - 1));

        int celdaDestino = m.getCelda(nuevaFila, nuevaCol);

        if (celdaDestino == 4 || celdaDestino == 5) {
            log("Esa casilla está ocupada por un enemigo. Elige otra dirección.");
            return;
        }

        m.setCelda(fila, col, 0);
        jugadorObj.mover(nuevaFila, nuevaCol);
        m.setCelda(nuevaFila, nuevaCol, 1);

        resolverCeldaPisada(celdaDestino, nuevaFila, nuevaCol);

        actualizarGrid();
        actualizarStats();

        faseActual = FaseTurno.INVENTARIO;
        log("Movimiento realizado. Puedes abrir el inventario o pasar directamente a la acción.");
    }


    // Resolver celda pisada
    private void resolverCeldaPisada(int tipoCelda, int fila, int col) {
        switch (tipoCelda) {
            case 2 -> resolverTesoro(fila, col);
            case 3 -> resolverTrampa(fila, col);
            case 6 -> resolverPuerta(false, fila, col);
            case 7 -> resolverPuerta(true,  fila, col);
            case 9 -> resolverVictoria();
        }
    }

    private void resolverTesoro(int fila, int col) {
        String[] pool = {"espada","hacha","arco","escudo",
                "yelmo","coraza","grebas","sabaton",
                "curacion","ofensiva","defensiva","agil",
                "antidoto","anticongelante","llave","moneda"};
        for (int i = 0; i < 6; i++) {
            objeto o = creador.crearObjeto(pool[rng.nextInt(pool.length)]);
            jugadorObj.addItem(o);
        }
        log("¡Encontraste un tesoro! Se añadieron 6 objetos a tu inventario.");
        actualizarInventarioUI();
    }

    private void resolverTrampa(int fila, int col) {
        String[] tipos = {"trampa_veneno", "trampa_congelacion", "trampa_danio"};
        trampa t = (trampa) creador.crearObjeto(tipos[rng.nextInt(3)]);

        switch (t.getEfecto()) {
            case "veneno" -> {
                if (!jugadorObj.tieneVeneno()) {
                    jugadorObj.setVeneno(true);
                    log("¡Trampa de veneno! Recibirás 3 de daño al inicio de cada turno hasta tomar un antídoto.");
                } else {
                    log("Pisaste una trampa de veneno, pero ya estabas envenenado. Sin efecto adicional.");
                }
            }
            case "congelacion" -> {
                if (!jugadorObj.estaCongelado()) {
                    jugadorObj.setCongelado(true);
                    log("¡Trampa de hielo! Tu velocidad se reduce en 1 hasta tomar un anticongelante.");
                } else {
                    log("Pisaste una trampa de hielo, pero ya estabas congelado. Sin efecto adicional.");
                }
            }
            case "danio" -> {
                jugadorObj.recibirDaño(t.getDañoPorTurno());
                log("¡Trampa explosiva! Recibes " + t.getDañoPorTurno() + " de daño. Vida: " + jugadorObj.getVida());
                comprobarMuerte();
            }
        }
    }

    private void resolverPuerta(boolean necesitaLlave, int fila, int col) {
        if (necesitaLlave) {
            int idx = -1;
            for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) {
                if (jugadorObj.getInventario().get(i) instanceof llave) {
                    idx = i;
                    break;
                }
            }
            if (idx == -1) {
                log("Esta puerta necesita una llave. No tienes ninguna.");
                return;
            }
            llave ll = (llave) jugadorObj.getInventario().get(idx);
            jugadorObj.getInventario().remove(ll);
            log("Usaste una llave para abrir la puerta.");
            actualizarInventarioUI();
        }
        cambiarDeSala();
    }

    private void resolverVictoria() {
        log("¡¡VICTORIA!! Has escapado de la mazmorra. ¡Enhorabuena!");
        deshabilitarControles();
        // Mostrar historial completo al final de la partida
        logPartida.vaciarMostrandoHistorial();
    }


    // Cambio de sala
    private void cambiarDeSala() {
        if (habitacionActual.aristasSalida.isEmpty()) {
            log("No hay salida disponible desde aquí.");
            return;
        }

        // Se usa la primera arista de salida disponible
        // (extensible: se podría pasar qué puerta se pisó para elegir arista)
        Arista<Matriz>  arista    = habitacionActual.aristasSalida.findElement(0);
        Vertice<Matriz> siguiente = arista.getDestino();

        habitacionActual.getData().setCelda(jugadorObj.getFila(), jugadorObj.getColumna(), 0);
        habitacionActual = siguiente;
        Matriz nuevaSala = habitacionActual.getData();

        int[] spawn = nuevaSala.buscarCelda(8);
        if (spawn[0] == -1) spawn = new int[]{nuevaSala.getFilas() / 2, nuevaSala.getColumnas() / 2};
        jugadorObj.setPosicion(spawn[0], spawn[1]);
        nuevaSala.setCelda(spawn[0], spawn[1], 1);

        rutaComprada = false;

        iniciarSala();
        actualizarGrid();
        actualizarStats();
        aplicarVenenoInicioTurno();
        log("Entraste en una nueva sala.");
    }


    // Botones FXML
    @FXML
    protected void onSaltarTurno() {
        if (faseActual == FaseTurno.ESPERA_ENEMIGOS) return;
        ejecutarTurnoEnemigos();
    }

    @FXML
    protected void onMoverse() {
        boolean quedanEnemigos = false;
        for (enemigo e : enemigosActuales){
            if (e.estaVivo()) quedanEnemigos = true; break;
        }
        if (faseActual != FaseTurno.MOVIMIENTO) {
            if (!quedanEnemigos) faseActual = FaseTurno.MOVIMIENTO;
            else {
                log("Ya pasó la fase de movimiento este turno.");
                return;
            }
        }
        actualizarGrid();
        gridHabitacion.requestFocus();
        log("Usa W/A/S/D + número de pasos + Enter. Velocidad actual: " + jugadorObj.getVelocidad());
    }

    @FXML
    protected void onAbrirInventario() {
        if (faseActual == FaseTurno.ESPERA_ENEMIGOS) return;
        mostrarInventario();
    }

    @FXML
    protected void onAccion() {
        if (faseActual == FaseTurno.ESPERA_ENEMIGOS) return;

        if (indiceInventarioSeleccionado >= 0
                && indiceInventarioSeleccionado < jugadorObj.getInventario().getSize()) {
            objeto o = jugadorObj.getInventario().get(indiceInventarioSeleccionado);
            if (o instanceof pocion p) {
                jugadorObj.fasePociones(p);
                log("Usaste: " + p.getNombre() + ". " + p.getDescripcion());
                indiceInventarioSeleccionado = -1;
                actualizarInventarioUI();
                actualizarStats();
                pasarAFaseEnemigos();
                return;
            }
        }

        atacarEnemigoEnRango();
    }

    /**
     * Eliminar monedas por referencia en lugar de por índice
     * para evitar el desplazamiento de índices.
     * Gracias al inventario ordenado, las monedas están siempre primero,
     * pero aun así se opera por referencia para máxima robustez.
     */
    @FXML
    protected void onComprarRuta() {
        // Recoger referencias a las 3 primeras monedas
        Lista_CDE<moneda> monedasEncontradas = new Lista_CDE<>();
        for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) {
            objeto o = jugadorObj.getInventario().get(i);
            if (o instanceof moneda m) {
                monedasEncontradas.add(m);
                if (monedasEncontradas.getSize() == 3) break;
            }
        }
        if (monedasEncontradas.getSize() < 3) {
            log("Necesitas 3 monedas para comprar la ruta. Tienes " + monedasEncontradas.getSize() + ".");
            return;
        }
        // Eliminar por referencia — seguro aunque el inventario cambie de tamaño
        for (int i = 0; i < 3; i++) {
            jugadorObj.getInventario().remove(monedasEncontradas.get(i));
        }
        rutaComprada = true;
        mostrarRutaEnLabels();
        actualizarInventarioUI();
        log("Ruta comprada. La verás durante la fase de movimiento de esta sala.");
    }


    // Ataque del jugador
    private void atacarEnemigoEnRango() {
        int rango = 1;
        arma armaEquipada = jugadorObj.getEquipo().getArma();
        if (armaEquipada != null) rango = armaEquipada.getAlcance();

        enemigo objetivo  = null;
        int     mejorDist = Integer.MAX_VALUE;

        for (enemigo e : enemigosActuales) {
            if (!e.estaVivo()) continue;
            int dist = Math.abs(jugadorObj.getFila() - e.getFila())
                     + Math.abs(jugadorObj.getColumna() - e.getColumna());
            if (dist <= rango && dist < mejorDist) {
                mejorDist = dist;
                objetivo  = e;
            }
        }

        if (objetivo == null) {
            log("No hay enemigos en rango. Acción desperdiciada.");
        } else {
            double random = rng.nextDouble();
            int    dano   = (int) Math.max(0,
                    jugadorObj.getAtaque() * (random * 2) - objetivo.getDefensa());
            objetivo.recibirDaño(dano);
            log("Atacaste al enemigo por " + dano + " de daño. Le quedan "
                    + objetivo.getVida() + " de vida.");
            if (!objetivo.estaVivo()) {
                habitacionActual.getData().setCelda(objetivo.getFila(), objetivo.getColumna(), 0);
                log("¡Enemigo derrotado!");
                actualizarGrid();
            }
        }
        pasarAFaseEnemigos();
    }


    // Turno de enemigos
    private void pasarAFaseEnemigos() {
        faseActual = FaseTurno.ESPERA_ENEMIGOS;
        ejecutarTurnoEnemigos();
    }

    private void ejecutarTurnoEnemigos() {
        jugadorObj.reducirDuracionBuffs();

        for (enemigo e : enemigosActuales) {
            if (!e.estaVivo()) continue;
            e.realizarTurno();
            actualizarPosicionEnemigos();  // actualizar después de CADA movimiento
            if (!jugadorObj.estaVivo()) {
                log("¡Has muerto! Fin de la partida.");
                deshabilitarControles();
                // FIX 2.13: mostrar historial al perder también
                logPartida.vaciarMostrandoHistorial();
                return;
            }
        }

        jugadorObj.resetTurno();

        if (rutaComprada && faseActual == FaseTurno.MOVIMIENTO) {
            mostrarRutaEnLabels();
        } else if (!rutaComprada && labelRuta != null) {
            labelRuta.setText("");
        }

        faseActual              = FaseTurno.MOVIMIENTO;
        venenoAplicadoEsteTurno = false;
        aplicarVenenoInicioTurno();

        actualizarGrid();
        actualizarStats();
        log("Turno de enemigos completado. Es tu turno.");
    }


    // Inventario — UI
    private void mostrarInventario() {
        actualizarInventarioUI();
        if (listaInventario == null) return;

        listaInventario.setOnMouseClicked(ev -> {
            int sel = listaInventario.getSelectionModel().getSelectedIndex();
            if (sel < 0) return;
            objeto o = jugadorObj.getInventario().get(sel);
            if (o == null) return;

            if (o instanceof pocion) {
                indiceInventarioSeleccionado = sel;
                log("Seleccionaste: " + o.getNombre() + ". Pulsa 'Acción' para usarla.");
            } else if (o instanceof arma || o instanceof armadura) {
                jugadorObj.faseInventario(o);
                log("Equipaste: " + o.getNombre());
                actualizarInventarioUI();
                actualizarStats();
            } else {
                log(o.getNombre() + ": " + o.getDescripcion());
            }
        });
    }

    private void actualizarInventarioUI() {
        if (listaInventario == null) return;
        listaInventario.getItems().clear();
        for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) {
            objeto o = jugadorObj.getInventario().get(i);
            listaInventario.getItems().add(i + ". " + o.toString());
        }

        if (labelEquipoArma    != null) labelEquipoArma.setText(
                jugadorObj.getEquipo().getArma()    != null ? jugadorObj.getEquipo().getArma().getNombre()    : "—");
        if (labelEquipoEscudo  != null) labelEquipoEscudo.setText(
                jugadorObj.getEquipo().getEscudo()  != null ? jugadorObj.getEquipo().getEscudo().getNombre()  : "—");
        if (labelEquipoYelmo   != null) labelEquipoYelmo.setText(
                jugadorObj.getEquipo().getYelmo()   != null ? jugadorObj.getEquipo().getYelmo().getNombre()   : "—");
        if (labelEquipoCoraza  != null) labelEquipoCoraza.setText(
                jugadorObj.getEquipo().getCoraza()  != null ? jugadorObj.getEquipo().getCoraza().getNombre()  : "—");
        if (labelEquipoGrebas  != null) labelEquipoGrebas.setText(
                jugadorObj.getEquipo().getGrebas()  != null ? jugadorObj.getEquipo().getGrebas().getNombre()  : "—");
        if (labelEquipoSabaton != null) labelEquipoSabaton.setText(
                jugadorObj.getEquipo().getSabaton() != null ? jugadorObj.getEquipo().getSabaton().getNombre() : "—");
    }


    // BFS de salas para mostrar ruta comprada
    private void mostrarRutaEnLabels() {
        int dist = bfsSalas();
        if (labelRuta != null) {
            labelRuta.setText("Salas hasta salida: " + dist
                    + "  |  Dist. puerta más cercana: " + distPuertaMasCercana());
        }
    }

    private int bfsSalas() {
        ListaSimplementeEnlazada<Vertice<Matriz>> cola       = new ListaSimplementeEnlazada<>();
        ListaSimplementeEnlazada<Vertice<Matriz>> vistos     = new ListaSimplementeEnlazada<>();
        ListaSimplementeEnlazada<Integer>         distancias = new ListaSimplementeEnlazada<>();

        cola.add(habitacionActual);
        vistos.add(habitacionActual);
        distancias.add(0);

        while (!cola.isEmpty()) {
            Vertice<Matriz> actual = cola.findElement(0);
            int             dist   = distancias.findElement(0);
            cola.del(actual);
            distancias.del(dist);

            if (actual == habitacionFinal) return dist;

            for (int i = 0; i < actual.aristasSalida.size(); i++) {
                Vertice<Matriz> vecino = actual.aristasSalida.findElement(i).getDestino();
                if (vistos.get(vecino) == null) {
                    vistos.add(vecino);
                    cola.add(vecino);
                    distancias.add(dist + 1);
                }
            }
        }
        return -1;
    }

    private int distPuertaMasCercana() {
        Matriz m   = habitacionActual.getData();
        int    jF  = jugadorObj.getFila();
        int    jC  = jugadorObj.getColumna();
        int    min = Integer.MAX_VALUE;

        for (int f = 0; f < m.getFilas(); f++) {
            for (int c = 0; c < m.getColumnas(); c++) {
                int v = m.getCelda(f, c);
                if (v == 6 || v == 7 || v == 9) {
                    int d = Math.abs(f - jF) + Math.abs(c - jC);
                    if (d < min) min = d;
                }
            }
        }
        return (min == Integer.MAX_VALUE) ? -1 : min;
    }


    // Renderizar el GridPane
    private void actualizarGrid() {
        gridHabitacion.getChildren().clear();
        Matriz m = habitacionActual.getData();

        m.setCelda(m.getFilas() / 2, m.getColumnas() - 1, 6);

        for (int f = 0; f < m.getFilas(); f++) {
            for (int c = 0; c < m.getColumnas(); c++) {
                int    val   = m.getCelda(f, c);
                String texto = switch (val) {
                    case 1 -> "P";
                    case 2 -> "T";
                    case 3 -> "T*";
                    case 4 -> "ED";
                    case 5 -> "EF";
                    case 6 -> "S";
                    case 7 -> "S🔒";
                    case 8 -> "E";
                    case 9 -> "EXIT";
                    default -> "";
                };

                Label celda = new Label(texto);
                celda.setMaxWidth(Double.MAX_VALUE);
                celda.setMaxHeight(Double.MAX_VALUE);
                celda.setAlignment(javafx.geometry.Pos.CENTER);

                String color = switch (val) {
                    case 1       -> "#4CAF50";
                    case 2       -> "#FFD700";
                    case 3       -> "#FF6600";
                    case 4       -> "#E53935";
                    case 5       -> "#B71C1C";
                    case 6, 8   -> "#2196F3";
                    case 7       -> "#9C27B0";
                    case 9       -> "#00BCD4";
                    default      -> "transparent";
                };
                celda.setStyle("-fx-background-color:" + color + ";-fx-font-weight:bold;");

                if (faseActual == FaseTurno.MOVIMIENTO && esCeldaAlcanzable(f, c)) {
                    celda.setStyle(celda.getStyle() + "-fx-border-color:yellow;-fx-border-width:2;");
                }

                GridPane.setColumnIndex(celda, c);
                GridPane.setRowIndex(celda, f);
                gridHabitacion.getChildren().add(celda);
            }
        }
    }

    private boolean esCeldaAlcanzable(int f, int c) {
        int jF  = jugadorObj.getFila();
        int jC  = jugadorObj.getColumna();
        int vel = jugadorObj.getVelocidad();
        if (f == jF && c != jC) return Math.abs(c - jC) <= vel;
        if (c == jC && f != jF) return Math.abs(f - jF) <= vel;
        return false;
    }


    // Stats del jugador
    private void actualizarStats() {
        if (labelVida        != null) labelVida.setText("Vida: "    + jugadorObj.getVida());
        if (labelAtaque      != null) labelAtaque.setText("Ataque: " + jugadorObj.getAtaque());
        if (labelDefensa     != null) labelDefensa.setText("Def: "   + jugadorObj.getDefensa());
        if (labelVelocidad   != null) labelVelocidad.setText("Vel: " + jugadorObj.getVelocidad());
        if (labelMovimientos != null) labelMovimientos.setText("Mov: " + jugadorObj.getVelocidad());
    }


    // Utilidades

    // El Log ahora apila el mensaje en PilaLog además de mostrarlo.
    private void log(String msg) {
        logPartida.push(msg);
        if (labelMensajes != null) labelMensajes.setText(msg);
        System.out.println("[LOG] " + msg);
    }

    private void comprobarMuerte() {
        if (!jugadorObj.estaVivo()) {
            log("¡Has muerto! Fin de la partida.");
            deshabilitarControles();
            logPartida.vaciarMostrandoHistorial();
        }
    }

    private void deshabilitarControles() {
        if (botonMoverse     != null) botonMoverse.setDisable(true);
        if (botonInventario  != null) botonInventario.setDisable(true);
        if (botonAccion      != null) botonAccion.setDisable(true);
        if (botonSaltarTurno != null) botonSaltarTurno.setDisable(true);
    }

    private int[] celdaVaciaAleatoria(Matriz m) {
        for (int i = 0; i < 100; i++) {
            int f = rng.nextInt(m.getFilas());
            int c = rng.nextInt(m.getColumnas());
            if (m.getCelda(f, c) == 0) return new int[]{f, c};
        }
        return new int[]{-1, -1};
    }

    /**
     * FIX colisiones entre enemigos: actualiza la posición de TODOS los
     * enemigos vivos en la matriz de una sola vez, limpiando primero las
     * celdas de enemigo y redibu jando solo los vivos.
     * Se llama después del turno de CADA enemigo para que el siguiente
     * enemigo ya vea la posición actualizada de sus compañeros.
     */
    private void actualizarPosicionEnemigos() {
        Matriz m = habitacionActual.getData();
        int tipoEnemigo = 4;
        // 1. Limpiar todas las celdas de enemigo
        for (int f = 0; f < m.getFilas(); f++) {
            for (int c = 0; c < m.getColumnas(); c++) {
                int v = m.getCelda(f, c);
                if (v == 4 || v == 5){
                    tipoEnemigo = v;
                    m.setCelda(f, c, 0);
                }
            }
        }

        // 2. Redibujar enemigos vivos
        for (enemigo en : enemigosActuales) {
            if (!en.estaVivo()) continue;
            // No pisar al jugador visualmente (el jugador siempre tiene valor 1)
            if (en.getFila() == jugadorObj.getFila()
                    && en.getColumna() == jugadorObj.getColumna()) continue;
            m.setCelda(en.getFila(), en.getColumna(), tipoEnemigo);
        }

        // 3. Redibujar jugador (por si la limpieza anterior lo sobreescribió)
        m.setCelda(jugadorObj.getFila(), jugadorObj.getColumna(), 1);
    }
}
