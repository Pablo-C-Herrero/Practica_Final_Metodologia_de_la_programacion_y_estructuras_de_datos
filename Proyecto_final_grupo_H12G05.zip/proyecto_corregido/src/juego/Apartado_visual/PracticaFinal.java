package juego.Apartado_visual;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class PracticaFinal extends Application {

    @Override
    public void start(Stage stage) throws IOException { // Se inicia la partida.
        FXMLLoader fxmlLoader = new FXMLLoader(PracticaFinal.class.getResource("title-view.fxml")); // Cargador de archivos.
        Scene scene = new Scene(fxmlLoader.load(), 900, 600); // Tamaño.
        stage.setTitle("Dungeon RPG");
        stage.setScene(scene); // Se pone esta ventana.
        stage.show(); // Se ve la ventana.
    }

    public static void main(String[] args) { // Se inicia JavaFX.
        launch();
    }
}
