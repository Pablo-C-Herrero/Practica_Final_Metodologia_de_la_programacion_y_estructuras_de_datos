package juego.turnos;

import java.util.Random;
import juego.personajes.jugador;
import juego.personajes.enemigo;
import juego.personajes.personaje;
import juego.estructuras.Cola_Prioridad.Cola_Prioridad;

public class turnos {

    private jugador j;
    private enemigo[] enemigos;
    private Random r = new Random();

    private int turnoActual = 0;

    public turnos(jugador j, enemigo[] enemigos) {
        this.j = j;
        this.enemigos = enemigos;
    }

    public Cola_Prioridad<personaje> iniciarRonda() { // Se inicia la ronda, donde se sacan las iniciativas para ver el orden de los turnos.
        Cola_Prioridad<personaje> cola = new Cola_Prioridad<>();
        int iniciativaJugador = r.nextInt(20) + 1; // Se randomiza la iniciativa.
        cola.enqueue(j, iniciativaJugador); // Se mete al jugador en la cola.
        System.out.println("Jugador saca iniciativa: " + iniciativaJugador);
        for (enemigo e : enemigos) { // Se hace lo mismo para los enemigos.
            if (e.estaVivo()) {
                int iniciativaEnemigo = r.nextInt(20) + 1;
                cola.enqueue(e, iniciativaEnemigo);
                System.out.println("Enemigo saca iniciativa: " + iniciativaEnemigo);
            }
        }
        return cola;
    }

    public void ejecutarRonda() { // Se lleva a cabo la ronda, sacando de la cola los personajes para que hagan sus acciones.
        Cola_Prioridad<personaje> cola = iniciarRonda();
        while (!cola.isEmpty()) {
            personaje actual = cola.dequeue();
            if (!actual.estaVivo()) continue;
            if (actual instanceof jugador jug) {
                ejecutarTurnoJugador(jug);
            } else if (actual instanceof enemigo en) {
                ejecutarTurnoEnemigo(en);
            }
        }
        turnoActual++;
    }


    public void ejecutarTurnoJugador(jugador jug) { // Es el turno del jugador.
        if (jug.tieneVeneno()) { // Si está envenenado.
            jug.recibirDaño(3);
            System.out.println("El jugador sufre 3 de daño por veneno. Vida: " + jug.getVida());
        }
        // Las fases de movimiento, inventario y acción las gestiona JuegoController.
        jug.reducirDuracionBuffs();
        jug.resetTurno();
    }

    public void ejecutarTurnoEnemigo(enemigo en) { // Es el turno de los enemigos.
        System.out.println("\n===== TURNO ENEMIGO =====");
        en.realizarTurno();
        en.resetTurno();
    }

    public int getTurnoActual() { return turnoActual; }
}
