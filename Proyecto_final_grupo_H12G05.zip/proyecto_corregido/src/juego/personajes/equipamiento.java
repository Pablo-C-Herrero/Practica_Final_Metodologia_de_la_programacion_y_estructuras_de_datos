package juego.personajes;

import juego.objetos.arma;
import juego.objetos.armadura;

public class equipamiento {

    private arma arma; // Esto es lo que se puede equipar.
    private arma escudo;
    private armadura yelmo;
    private armadura coraza;
    private armadura grebas;
    private armadura sabaton;


// Métodos para equipar las cosas.
    public void equiparArma(arma nuevaArma){ this.arma = nuevaArma; }
    public void equiparEscudo(arma nuevoEscudo){ this.escudo = nuevoEscudo; }

    public void equiparYelmo(armadura a){ this.yelmo = a; }
    public void equiparCoraza(armadura a){ this.coraza = a; }
    public void equiparGrebas(armadura a){ this.grebas = a; }
    public void equiparSabaton(armadura a){ this.sabaton = a; }


// Getters.
    public arma getArma(){ return arma; }
    public arma getEscudo(){ return escudo; }

    public armadura getYelmo(){ return yelmo; }
    public armadura getCoraza(){ return coraza; }
    public armadura getGrebas(){ return grebas; }
    public armadura getSabaton(){ return sabaton; }




// Buff por armas/equipamiento.
    public int bonusDefensaTotal(){ // La defensa.
        int total = 0; // Se inicia en 0.
        if(yelmo != null) total += yelmo.getBonusDefensa();
        if(coraza != null) total += coraza.getBonusDefensa();
        if(grebas != null) total += grebas.getBonusDefensa();
        if(sabaton != null) total += sabaton.getBonusDefensa();
        if(escudo != null) total += escudo.getBonusDefensa(); // Se suman los posibles buff.
        total -= penalizacionDefensaTotal(); // Se quitan los debuff.
        return total;
    }
    public int penalizacionDefensaTotal() { // Debuff defensivo.
        int total = 0; // Se inicializa en 0.
        if(arma != null) total += arma.getPenalizacionDefensa(); // El debuff a la defensa, si lo tiene, del arma.
        return total;
    }

    public int bonusAtaqueTotal(){ // Buff ofensivo.
        int total = 0;
        if(arma != null) total += arma.getBonusAtaque(); // Lo da solo el arma.
        return total;
    }

    public int bonusVelocidadTotal() {
        int bonus = 0;
        if (arma != null) bonus += arma.getBonusVelocidad();      // arco +velocidad
        if (sabaton != null) bonus += sabaton.getBonusVelocidad();   // sabatón +velocidad
        bonus -= penalizacionVelocidadTotal();
        return bonus;
    }

    public int penalizacionVelocidadTotal() { // Igual que en los otros.
        int total = 0; // Se inicializa en 0.
        if(arma != null) total += arma.getPenalizacionVelocidad();
        if(yelmo != null) total += yelmo.getPenalizacionVelocidad();
        if(coraza != null) total += coraza.getPenalizacionVelocidad();
        if(grebas != null) total += grebas.getPenalizacionVelocidad();
        if(sabaton != null) total += sabaton.getPenalizacionVelocidad(); // Se suman las penalizaciones.
        return total;
    }
}