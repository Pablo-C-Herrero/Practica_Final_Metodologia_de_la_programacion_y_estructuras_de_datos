package juego.personajes;

import juego.estructuras.Lista_CDE.Lista_CDE;
import juego.objetos.*;


public class inventario {

    private Lista_CDE<objeto> items = new Lista_CDE<>();


    private static int categoria(objeto o) {
        if (o instanceof moneda) return 0;
        if (o instanceof llave) return 1;
        if (o instanceof arma) return 2;   // El escudo también es un arma.
        if (o instanceof armadura) return 3;
        if (o instanceof pocion) return 4;
        return 5; // otros (trampa, etc.)
    }


    public void add(objeto o) { // Metodo para añadir un objeto al inventario.
        int catO = categoria(o); // El tipo del objeto.
        int size = items.getSize();
        // Buscar el primer índice cuya categoría sea estrictamente mayor (están asignados los tipos con valores para colocarlos con preferencia).
        for (int i = 0; i < size; i++) {
            if (categoria(items.get(i)) > catO) {
                items.add(i, o);
                return;
            }
        }
        // Si no se encontró ningún elemento de categoría mayor, añadir al final.
        items.add(o);
    }

    public objeto get(int i) {
        return items.get(i);
    }

    public boolean remove(objeto o) {
        return items.remove(o);
    }

    public int getSize() {
        return items.getSize();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public Lista_CDE<objeto> getLista() {
        return items;
    }
}
