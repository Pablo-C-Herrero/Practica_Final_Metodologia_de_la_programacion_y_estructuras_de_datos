package juego.estructuras.Pila;


public class PilaLog<E> {


    private static class Nodo<E> {
        E dato;
        Nodo<E> siguiente;
        Nodo(E dato, Nodo<E> siguiente) {
            this.dato = dato;
            this.siguiente = siguiente;
        }
    }


    private Nodo<E> cima;   // Nodo en la cima de la pila (null si vacía).
    private int size;   // Número de elementos almacenados.


    public PilaLog() {
        cima = null;
        size = 0;
    }



    public void push(E elemento) { // Añadir un elemento a la pila.
        cima = new Nodo<>(elemento, cima);
        size++;
    }


    public E pop() { // Sacar un elemento de la pila.
        if (isEmpty()) {
            System.out.println("[PilaLog] La pila está vacía; no se puede desapilar.");
            return null;
        }
        E dato = cima.dato;
        cima = cima.siguiente;
        size--;
        return dato;
    }


    public E peek() { // Mirar el elemento superior de la pila.
        if (isEmpty()) {
            System.out.println("[PilaLog] La pila está vacía; no hay cima que mostrar.");
            return null;
        }
        return cima.dato;
    }


    public boolean isEmpty() {
        return cima == null;
    }

    public int getSize() {
        return size;
    }



    public void vaciarMostrandoHistorial() { // Se muestra el historial de la partida (el Log).
        System.out.println("\n========== HISTORIAL DE PARTIDA ==========");
        if (isEmpty()) {
            System.out.println("  (sin eventos registrados)");
            System.out.println("==========================================\n");
            return;
        }
        int num = size; // Guardamos el total antes de vaciar.
        for (int i = num; i >= 1; i--) { // Se recorre la pila.
            System.out.println("  [" + i + "] " + pop()); // Se sacan los elementos en orden inverso al que han sucedido.
        }
        System.out.println("==========================================\n");
    }


    public String obtenerHistorialComoTexto() { // Se saca el log como un texto. .
        if (isEmpty()) return "(sin eventos)";
        // Recorremos sin destruir la pila usando un nodo auxiliar.
        StringBuilder sb  = new StringBuilder();
        Nodo<E> aux = cima;
        int num = size;
        while (aux != null) {
            sb.append("[").append(num--).append("] ").append(aux.dato).append("\n");
            aux = aux.siguiente;
        }
        return sb.toString();
    }
}
