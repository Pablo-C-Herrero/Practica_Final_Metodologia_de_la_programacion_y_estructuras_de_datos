package juego.estructuras.Cola_Prioridad;

public class Cola_Prioridad<E>{

    private Nodo_Cola_Prioridad<E> cabeza;
    private int size;


    public Cola_Prioridad() {
        this.cabeza = null;
        this.size = 0;
    }


    public void enqueue(E elemento, int prioridad) {
        Nodo_Cola_Prioridad<E> nuevo = new Nodo_Cola_Prioridad<E>(elemento, prioridad); // Se crea un nuevo elemento para añadir a la cola al que se le da una prioridad para salir con un orden determinado.
        if (cabeza == null || prioridad > cabeza.getPrior()) { // Si no hay elementos en la cabeza y/o
            nuevo.setSiguienteelemento(cabeza); // El nodo creado apunta al nodo de antes.
            cabeza = nuevo; // El nuevo nodo pasa a ser la cabeza.
        }
        else {
            Nodo_Cola_Prioridad<E> actual = cabeza; // Se crea el puntero.
            while (actual.getSiguienteelemento() != null && actual.getSiguienteelemento().getPrior() >= prioridad) { // Se busca la posición donde hay que añadir el elemento.
                actual = actual.getSiguienteelemento();
            }
            nuevo.setSiguienteelemento(actual.getSiguienteelemento()); // Se apunta al siguiente nodo.
            actual.setSiguienteelemento(nuevo); // El nodo "actual" apunta al nuevo elemento.
        }
        size += 1; // Se amplía el tamaño de la cola.
    }



    public E dequeue() {
        if (cabeza == null) { // Si está vacía no se puede eliminar nada.
            System.out.println("La cola no tiene elementos para sacar");
            return null;
        }
        E dato = cabeza.getDato(); // Se "guarda" la cabeza en el dato.
        cabeza = cabeza.getSiguienteelemento(); // La cabeza pasa a ser el siguiente elemento de la cabeza.
        size -= 1; // Se disminuye en 1 la cola.
        return dato; // Se retorna el dato que se ha guardado antes.
    }



    public E peek() {
        if (cabeza == null) { // Si la cola está vacía no se puede ver nada.
            System.out.println("No hay nada que ver");
            return null;
        }
        else {
            return cabeza.getDato(); // Se retorna la cabeza.
        }
    }



    public int getSize() {
        return this.size;
    } // Se devuelve el tamaño calculado en los otros métodos.


    public boolean isEmpty() {
        return cabeza == null;
    } // Si cabeza == null retorna True, si no, false.
}
