package juego.estructuras.Cola_Prioridad;

public class Nodo_Cola_Prioridad<E> {

    private E dato;
    private int prioridad;
    private Nodo_Cola_Prioridad<E> siguienteelemento;



    public Nodo_Cola_Prioridad(E dato, int prioridad) { // Se introduce un elemento, por lo que el siguiente no existe.
        this.dato = dato;
        this.prioridad = prioridad;
        this.siguienteelemento = null;
    }


    // Setters y getters.
    public E getDato() {
        return this.dato;
    }

    public int getPrior() {
        return this.prioridad;
    }

    public Nodo_Cola_Prioridad<E> getSiguienteelemento() {
        return this.siguienteelemento;
    }



    public void setDato(E dato) {
        this.dato = dato;
    }

    public void setPrior(int prioridad) {
        this.prioridad = prioridad;
    }

    public void setSiguienteelemento(Nodo_Cola_Prioridad<E> siguienteelemento) {
        this.siguienteelemento = siguienteelemento;
    }
}
