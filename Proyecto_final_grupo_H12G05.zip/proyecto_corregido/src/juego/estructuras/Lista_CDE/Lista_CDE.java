package juego.estructuras.Lista_CDE;

public class Lista_CDE<E> {

    private NodoDE<E> cabeza;
    private int size;



    public Lista_CDE() {
        cabeza = null;
        size = 0;
    }



    public void add(E elemento) { // Metodo para añadir un elemento.
        NodoDE<E> nuevo = new NodoDE<E>(elemento);
        if (cabeza == null) {
            cabeza = nuevo;
            cabeza.setSiguienteelemento(cabeza);
            cabeza.setAnteriorelemento(cabeza);
        }
        else {
            NodoDE<E> ultimo = cabeza.getAnteriorelemento();

            ultimo.setSiguienteelemento(nuevo);
            nuevo.setAnteriorelemento(ultimo);

            nuevo.setSiguienteelemento(cabeza);
            cabeza.setAnteriorelemento(nuevo);
        }
        size += 1;
    }



    public void add(int posicion, E elemento) { // Metodo para añadir un elemento en una posición determinada.
        NodoDE<E> nuevo = new NodoDE<E>(elemento);
        if (posicion < 0 || posicion > size) { // Si no está en el rango.
            System.out.println("No se puede añadir ningún elemento en esa posición.");
            return;
        }
        if (posicion == 0) { // Si la posición es la 0.
            if (cabeza == null) { // Si no hay nada.
                cabeza = nuevo; // Se relaciona consigo mismo.
                cabeza.setSiguienteelemento(cabeza);
                cabeza.setAnteriorelemento(cabeza);
            }
            else { // Si hay, al menos, un elemento.
                NodoDE<E> ultimo = cabeza.getAnteriorelemento();
                nuevo.setSiguienteelemento(cabeza); // Se pone el primero, el siguiente es el que era la cabeza, y el anterior el último.
                nuevo.setAnteriorelemento(ultimo);
                ultimo.setSiguienteelemento(nuevo);
                cabeza.setAnteriorelemento(nuevo);
                cabeza = nuevo;
            }
        }
        else { // Si se pone en otra posición.
            NodoDE<E> actual = cabeza;
            for (int i = 0; i < posicion - 1; i = i+1) { // Se llega a la posicón.
                actual = actual.getSiguienteelemento();
            }
            NodoDE<E> siguiente = actual.getSiguienteelemento();
            actual.setSiguienteelemento(nuevo); // Se crean las relaciones nuevas.
            nuevo.setAnteriorelemento(actual);
            nuevo.setSiguienteelemento(siguiente);
            siguiente.setAnteriorelemento(nuevo);
        }
        size += 1;
    }



    public E remove(int posicion) { // Metodo para quitar el elemento de una posición determinada.
        if (posicion < 0 || posicion >= size) {
            System.out.println("No se puede eliminar un elemento de esa posición.");
            return null;
        }
        NodoDE<E> eliminado;
        if (posicion == 0) {
            eliminado = cabeza;
            if (size == 1) { // Si solo hay un elemento, pasa a no haber ninguno.
                cabeza = null;
            }
            else { // Se quita y se crean las conexiones nuevas.
                NodoDE<E> ultimo = cabeza.getAnteriorelemento();
                cabeza = cabeza.getSiguienteelemento();
                cabeza.setAnteriorelemento(ultimo);
                ultimo.setSiguienteelemento(cabeza);
            }
        }
        else { // Se busca y se crean las conexiones nuevas.
            NodoDE<E> actual = cabeza;
            for (int i = 0; i < posicion; i = i+1) {
                actual = actual.getSiguienteelemento();
            }
            eliminado = actual;
            NodoDE<E> anterior = actual.getAnteriorelemento();
            NodoDE<E> siguiente = actual.getSiguienteelemento();
            anterior.setSiguienteelemento(siguiente);
            siguiente.setAnteriorelemento(anterior);
        }
        size -= 1;
        return eliminado.getDato();
    }




    public boolean remove(E elemento){ // Metodo para eliminar un elemento de la lista.
        int posicion = getIndex(elemento);
        if(posicion == -1){
            return false;
        }
        remove(posicion);
        return true;
    }



    public E get(int posicion) { // Metodo para ver la información del dato que está en la posición pos.
        if (posicion < 0 || posicion >= size) {
            System.out.println("Esa posición no existe");
            return null;
        }
        NodoDE<E> actual = cabeza;
        for (int i = 0; i < posicion; i = i+1) {
            actual = actual.getSiguienteelemento();
        }
        return actual.getDato();
    }



    public int getIndex(E elemento) {
        NodoDE<E> actual = cabeza;
        for (int i = 0; i < size; i = i+1) {
            if (actual.getDato() !=null && actual.getDato().equals(elemento)) {
                return i;
            }
            actual = actual.getSiguienteelemento();
        }
        return -1;
    }



    public boolean contiene(E elemento) {
        return getIndex(elemento) != -1;
    }


    public int getSize() {
        return size;
    }


    public boolean isEmpty() {
        return size == 0;
    }
}
