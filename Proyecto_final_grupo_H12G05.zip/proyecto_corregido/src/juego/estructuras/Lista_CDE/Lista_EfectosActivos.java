package juego.estructuras.Lista_CDE;

public class Lista_EfectosActivos {


    public static class EfectoActivo {

        // Qué tipo de stat modifica: "ataque", "defensa", "velocidad"
        private final String tipo;
        // Cuántos puntos suma mientras está activo
        private final int bonus;
        // Cuántos turnos le quedan.
        private int duracionRestante;

        public EfectoActivo(String tipo, int bonus, int duracion) {
            this.tipo = tipo;
            this.bonus = bonus;
            this.duracionRestante = duracion;
        }

        public String getTipo() { return tipo; }
        public int getBonus() { return bonus; }
        public int getDuracionRestante(){ return duracionRestante; }


        public boolean decrementar() { // Metodo para reducir la duración de los turnos de las pociones.
            duracionRestante--;
            return duracionRestante <= 0;
        }

        @Override
        public String toString() {
            return "Efecto[" + tipo + " +" + bonus + " durante " + duracionRestante + " turno(s)]";
        }
    }


    private NodoDE<EfectoActivo> cabeza;
    private int size;

    public Lista_EfectosActivos() {
        cabeza = null;
        size   = 0;
    }


    public void add(EfectoActivo efecto) { // Se añade un efecto.
        NodoDE<EfectoActivo> nuevo = new NodoDE<>(efecto);
        if (cabeza == null) { // Si no hay ningún efecto.
            cabeza = nuevo; // Se añade el elemento como la cabeza, y el anterior y el siguiente son él mismo.
            cabeza.setSiguienteelemento(cabeza);
            cabeza.setAnteriorelemento(cabeza);
        } else { // Si hay, al menos, un elemento.
            NodoDE<EfectoActivo> ultimo = cabeza.getAnteriorelemento();
            ultimo.setSiguienteelemento(nuevo); // Se añade al final.
            nuevo.setAnteriorelemento(ultimo);
            nuevo.setSiguienteelemento(cabeza); // SE conecta con la cabeza (el primer elemento).
            cabeza.setAnteriorelemento(nuevo);
        }
        size++;
    }


    public void tick() { // Metodo para reducir la duración de los efectos de las pociones y, en caso de que la duración sea 0, se quita el efecto.
        if (cabeza == null) return; // Si no hay nada, no hay nada que hacer.
        NodoDE<EfectoActivo> actual = cabeza; // Nos colocamos en la cabeza.
        int procesados = 0; // No se ha mirado ninguno todavía.
        while (procesados < size) { // Mientras que no se hayan mirado todos menos uno.
            NodoDE<EfectoActivo> siguiente = actual.getSiguienteelemento(); // Avanzamos.
            boolean caduco = actual.getDato().decrementar(); // Se decrementa en 1 la duración.
            if (caduco) {
                // Eliminar nodo de la lista circular
                if (size == 1) {
                    cabeza = null;
                    size   = 0;
                    return; // Lista vacía, terminamos
                }
                NodoDE<EfectoActivo> ant = actual.getAnteriorelemento();
                NodoDE<EfectoActivo> sig = actual.getSiguienteelemento();
                ant.setSiguienteelemento(sig); // Se relacionan el anterior y el siguiente del eliminado.
                sig.setAnteriorelemento(ant);
                if (actual == cabeza) cabeza = sig;
                size--;
            }
            actual = siguiente; // Se pasa al siguiente.
            procesados++; // Se ha mirado uno.
        }
    }


    public int getTotalBonus(String tipo) { // Metodo para sumar los buff de un tipo concreto de buff.
        if (cabeza == null) return 0;
        int total = 0; // Se inicializa en 0.
        NodoDE<EfectoActivo> actual = cabeza;
        for (int i = 0; i < size; i++) { // Se miran todos los elementos en la lista.
            if (actual.getDato().getTipo().equals(tipo)) { // Si son del mismo tipo.
                total += actual.getDato().getBonus(); // Se suma el buff.
            }
            actual = actual.getSiguienteelemento();
        }
        return total;
    }


    public void eliminarPorTipo(String tipo) { // Eliminar los efectos de un tipo.
        if (cabeza == null) return;
        NodoDE<EfectoActivo> actual = cabeza;
        int procesados = 0;
        while (procesados < size) {
            NodoDE<EfectoActivo> siguiente = actual.getSiguienteelemento();
            if (actual.getDato().getTipo().equals(tipo)) {
                if (size == 1) {
                    cabeza = null;
                    size   = 0;
                    return;
                }
                NodoDE<EfectoActivo> ant = actual.getAnteriorelemento();
                NodoDE<EfectoActivo> sig = actual.getSiguienteelemento();
                ant.setSiguienteelemento(sig);
                sig.setAnteriorelemento(ant);
                if (actual == cabeza) cabeza = sig;
                size--;
                // No incrementamos procesados porque size ya bajó.
            } else {
                procesados++;
            }
            actual = siguiente;
        }
    }

    public boolean isEmpty() { return size == 0; }
    public int     getSize() { return size; }
}
