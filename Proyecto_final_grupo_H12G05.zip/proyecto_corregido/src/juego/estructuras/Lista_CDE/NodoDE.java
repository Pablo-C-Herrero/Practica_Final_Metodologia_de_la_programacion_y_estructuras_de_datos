package juego.estructuras.Lista_CDE;

public class NodoDE<E> {

    private E dato;
    private NodoDE<E> siguienteelemento;
    private NodoDE<E> anteriorelemento;


    public NodoDE(E dato) {
        this.dato = dato;
        this.siguienteelemento = null;
        this.anteriorelemento = null;
    }


    // Getters y setters.
    public E getDato() {
        return this.dato;
    }

    public void setDato(E dato) {
        this.dato = dato;
    }



    public NodoDE<E> getSiguienteelemento() {
        return this.siguienteelemento;
    }
    public NodoDE<E> getAnteriorelemento() {
        return this.anteriorelemento;
    }

    public void setSiguienteelemento(NodoDE<E> siguienteelemento) {
        this.siguienteelemento = siguienteelemento;
    }
    public void setAnteriorelemento(NodoDE<E> anteriorelemento) {
        this.anteriorelemento = anteriorelemento;
    }
}
