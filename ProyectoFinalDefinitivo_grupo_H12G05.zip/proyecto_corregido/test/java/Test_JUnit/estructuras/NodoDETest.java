package Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class NodoDETest {

    @Test
    void getDato() {
    }

    @Test
    void setDato() {
    }

    @Test
    void getSiguienteelemento() {
    }

    @Test
    void getAnteriorelemento() {
    }

    @Test
    void setSiguienteelemento() {
    }

    @Test
    void setAnteriorelemento() {
    }
}