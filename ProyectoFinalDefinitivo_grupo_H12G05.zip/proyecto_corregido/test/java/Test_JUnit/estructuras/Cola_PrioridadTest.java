package Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Cola_PrioridadTest {

    @Test
    void enqueue() {
    }

    @Test
    void dequeue() {
    }

    @Test
    void peek() {
    }

    @Test
    void getSize() {
    }

    @Test
    void isEmpty() {
    }
}