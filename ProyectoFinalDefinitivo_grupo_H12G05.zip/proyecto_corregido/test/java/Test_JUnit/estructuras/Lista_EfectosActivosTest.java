package Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Lista_EfectosActivosTest {

    @Test
    void add() {
    }

    @Test
    void tick() {
    }

    @Test
    void getTotalBonus() {
    }

    @Test
    void eliminarPorTipo() {
    }

    @Test
    void isEmpty() {
    }

    @Test
    void getSize() {
    }
}