package Test_JUnit.estructuras;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Nodo_Cola_PrioridadTest {

    @Test
    void getDato() {
    }

    @Test
    void getPrior() {
    }

    @Test
    void getSiguienteelemento() {
    }

    @Test
    void setDato() {
    }

    @Test
    void setPrior() {
    }

    @Test
    void setSiguienteelemento() {
    }
}