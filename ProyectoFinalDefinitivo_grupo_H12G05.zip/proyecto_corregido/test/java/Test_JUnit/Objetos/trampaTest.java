package Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class trampaTest {

    @Test
    void getEfecto() {
    }

    @Test
    void setDañoPorTurno() {
    }

    @Test
    void getDañoPorTurno() {
    }
}