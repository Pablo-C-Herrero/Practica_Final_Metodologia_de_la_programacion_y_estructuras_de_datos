package Test_JUnit.Objetos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class puertaTest {

    @Test
    void getFila() {
    }

    @Test
    void getColumna() {
    }

    @Test
    void getTipo() {
    }

    @Test
    void setTipo() {
    }

    @Test
    void estaAbierta() {
    }

    @Test
    void necesitaLlave() {
    }

    @Test
    void abrir() {
    }
}