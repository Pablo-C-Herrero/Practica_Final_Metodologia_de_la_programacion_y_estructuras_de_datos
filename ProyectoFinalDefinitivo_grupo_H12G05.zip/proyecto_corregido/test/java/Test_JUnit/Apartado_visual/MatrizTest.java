package Test_JUnit.Apartado_visual;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import juego.Apartado_visual.EstructurasUtilizadas.Matriz;

class MatrizTest {

    @Test
    void getFilas() {
    }

    @Test
    void getColumnas() {
    }

    @Test
    void getMatrizFormatoLista() {
    }

    @Test
    void getCelda() {
    }

    @Test
    void setCelda() {
    }

    @Test
    void buscarCelda() {
    }

    @Test
    void compareTo() {
    }
}