package Test_JUnit.Apartado_visual;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import juego.Apartado_visual.EstructurasUtilizadas.Grafo;

class GrafoTest {

    @Test
    void getVertices() {
    }

    @Test
    void getAristas() {
    }

    @Test
    void addVertice() {
    }

    @Test
    void addArista() {
    }

    @Test
    void isGrafoSimple() {
    }

    @Test
    void isGrafoDirigido() {
    }

    @Test
    void isCompleto() {
    }

    @Test
    void isConexo() {
    }

    @Test
    void isArbol() {
    }
}