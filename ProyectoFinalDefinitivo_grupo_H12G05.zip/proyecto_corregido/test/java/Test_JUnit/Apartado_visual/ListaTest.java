package Test_JUnit.Apartado_visual;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import juego.Apartado_visual.EstructurasUtilizadas.Lista;

class ListaTest {

    @Test
    void add() {
    }

    @Test
    void get() {
    }

    @Test
    void del() {
    }

    @Test
    void isEmpty() {
    }

    @Test
    void size() {
    }

    @Test
    void getIterador() {
    }

    @Test
    void findElement() {
    }

    @Test
    void findPosition() {
    }
}