package Test_JUnit.Apartado_visual;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import juego.Apartado_visual.EstructurasUtilizadas.IteradorLC;

class IteradorLCTest {

    @Test
    void hasNext() {
    }

    @Test
    void next() {
    }
}