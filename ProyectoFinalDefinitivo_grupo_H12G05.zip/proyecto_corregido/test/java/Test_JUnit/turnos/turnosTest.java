package Test_JUnit.turnos;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class turnosTest {

    @Test
    void iniciarRonda() {
    }

    @Test
    void ejecutarRonda() {
    }

    @Test
    void ejecutarTurnoJugador() {
    }

    @Test
    void ejecutarTurnoEnemigo() {
    }

    @Test
    void getTurnoActual() {
    }
}