package Test_JUnit.Personajes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class enemigoTest {

    @Test
    void setCeldaLibre() {
    }

    @Test
    void recibirDaño() {
    }

    @Test
    void mover() {
    }

    @Test
    void marcarMovimientoConsumido() {
    }

    @Test
    void realizarTurno() {
    }

    @Test
    void compareTo() {
    }
}