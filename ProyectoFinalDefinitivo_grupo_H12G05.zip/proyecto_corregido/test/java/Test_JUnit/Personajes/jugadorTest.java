package Test_JUnit.Personajes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class jugadorTest {

    @Test
    void curar() {
    }

    @Test
    void tieneVeneno() {
    }

    @Test
    void estaCongelado() {
    }

    @Test
    void setVeneno() {
    }

    @Test
    void setCongelado() {
    }

    @Test
    void aplicarBuffAtaque() {
    }

    @Test
    void aplicarBuffDefensa() {
    }

    @Test
    void aplicarBuffVelocidad() {
    }

    @Test
    void reducirDuracionBuffs() {
    }

    @Test
    void getEfectosActivos() {
    }

    @Test
    void getAtaque() {
    }

    @Test
    void getDefensa() {
    }

    @Test
    void getVelocidad() {
    }

    @Test
    void addItem() {
    }

    @Test
    void getInventario() {
    }

    @Test
    void getAtaqueInventario() {
    }

    @Test
    void getDefensaInventario() {
    }

    @Test
    void faseInventario() {
    }

    @Test
    void fasePociones() {
    }

    @Test
    void maxAtaqueInventario() {
    }

    @Test
    void maxDefensaInventario() {
    }

    @Test
    void realizarTurno() {
    }

    @Test
    void getEquipo() {
    }

    @Test
    void equipar() {
    }
}