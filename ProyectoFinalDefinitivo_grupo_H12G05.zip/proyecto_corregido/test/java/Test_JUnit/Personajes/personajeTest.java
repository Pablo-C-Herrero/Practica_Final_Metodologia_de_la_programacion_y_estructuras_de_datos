package Test_JUnit.Personajes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class personajeTest {

    @Test
    void resetTurno() {
    }

    @Test
    void estaVivo() {
    }

    @Test
    void getVida() {
    }

    @Test
    void getAtaque() {
    }

    @Test
    void getDefensa() {
    }

    @Test
    void getVelocidad() {
    }

    @Test
    void getTipo() {
    }

    @Test
    void recibirDaño() {
    }

    @Test
    void mover() {
    }

    @Test
    void getFila() {
    }

    @Test
    void getColumna() {
    }

    @Test
    void getUltFila() {
    }

    @Test
    void getUltColumna() {
    }

    @Test
    void setPosicion() {
    }

    @Test
    void setFila() {
    }

    @Test
    void setColumna() {
    }

    @Test
    void realizarTurno() {
    }
}