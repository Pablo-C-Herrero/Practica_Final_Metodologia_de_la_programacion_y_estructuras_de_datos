package Test_JUnit.Personajes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class equipamientoTest {

    @Test
    void equiparArma() {
    }

    @Test
    void equiparEscudo() {
    }

    @Test
    void equiparYelmo() {
    }

    @Test
    void equiparCoraza() {
    }

    @Test
    void equiparGrebas() {
    }

    @Test
    void equiparSabaton() {
    }

    @Test
    void getArma() {
    }

    @Test
    void getEscudo() {
    }

    @Test
    void getYelmo() {
    }

    @Test
    void getCoraza() {
    }

    @Test
    void getGrebas() {
    }

    @Test
    void getSabaton() {
    }

    @Test
    void bonusDefensaTotal() {
    }

    @Test
    void penalizacionDefensaTotal() {
    }

    @Test
    void bonusAtaqueTotal() {
    }

    @Test
    void bonusVelocidadTotal() {
    }

    @Test
    void penalizacionVelocidadTotal() {
    }
}