package juego.estructuras.ArbolDecision;

public class ArbolDecisionEnemigo {


    private static class NodoDecision {

        // Funcional interface: condición booleana evaluada en tiempo de ejecución.
        @FunctionalInterface
        interface Condicion {
            boolean evaluar(ContextoEnemigo ctx);
        }

        // Funcional interface: acción a ejecutar en las hojas del árbol.
        @FunctionalInterface
        interface Accion {
            void ejecutar(ContextoEnemigo ctx);
        }

        final Condicion pregunta; // null en hojas
        final Accion accion;   // null en nodos interiores
        final NodoDecision hijoSi;   // rama "sí" (condición verdadera)
        final NodoDecision hijoNo;   // rama "no" (condición falsa)

        // Constructor de NodoDecisión (pregunta con dos hijos).
        NodoDecision(Condicion pregunta, NodoDecision hijoSi, NodoDecision hijoNo) {
            this.pregunta = pregunta;
            this.hijoSi   = hijoSi;
            this.hijoNo   = hijoNo;
            this.accion   = null;
        }


        NodoDecision(Accion accion) {
            this.accion   = accion;
            this.pregunta = null;
            this.hijoSi   = null;
            this.hijoNo   = null;
        }


        boolean esHoja() {
            return accion != null;
        }
    }


    public static class ContextoEnemigo { // Es un metodo que condensa lo que se necesita usar para hacer que la IA decida.

        // Posición actual del enemigo.
        public int filaEnemigo;
        public int columnaEnemigo;

        // Posición actual del jugador.
        public final int filaJugador;
        public final int columnaJugador;

        // Rango de ataque del arma equipada del enemigo.
        public final int rangoAtaque;

        // Ataque del enemigo y defensa del jugador (para la fórmula de daño).
        public final int ataqueEnemigo;
        public final int defensaJugador;

        // Referencia al jugador para poder aplicarle daño.
        public final ObjetivoAtacable jugador;

        // Referencia al objeto enemigo para poder llamar a mover().
        public final MovibleEnemigo enemigo;

        public ContextoEnemigo(int filaEnemigo, int columnaEnemigo, int filaJugador, int columnaJugador, int rangoAtaque, int ataqueEnemigo, int defensaJugador,
                               ObjetivoAtacable jugador, MovibleEnemigo   enemigo) {
            this.filaEnemigo = filaEnemigo;
            this.columnaEnemigo = columnaEnemigo;
            this.filaJugador = filaJugador;
            this.columnaJugador = columnaJugador;
            this.rangoAtaque = rangoAtaque;
            this.ataqueEnemigo  = ataqueEnemigo;
            this.defensaJugador = defensaJugador;
            this.jugador = jugador;
            this.enemigo = enemigo;
        }

        // Distancia entre el jugador y el enemigo.
        public int distancia() {
            return Math.abs(filaEnemigo    - filaJugador) + Math.abs(columnaEnemigo - columnaJugador);
        }
    }




   // Son los datos del objetivo que se vaya a atacar y que se necesitan para calcular el daño.
    public interface ObjetivoAtacable {
        void recibirDaño(int cantidad);
        int  getDefensa();
    }

    // Metodo para mover al enemigo.
    public interface MovibleEnemigo {
        void mover(int nuevaFila, int nuevaColumna);
        void marcarMovimientoConsumido(); // equivale a haMovido = true sin mover
    }



    private final NodoDecision raiz;


    public ArbolDecisionEnemigo() {

        // Hoja: atacar (se reutiliza en ambas ramas que terminan atacando).
        NodoDecision hojaAtacar = new NodoDecision(ctx -> {
            double random = Math.random();
            int dano = (int) Math.max(0, ctx.ataqueEnemigo * (random * 2) - ctx.defensaJugador);
            ctx.jugador.recibirDaño(dano);
            System.out.println("[IA] Enemigo ataca por " + dano + " de daño.");
        });

        // Hoja: no atacar (el jugador sigue fuera de rango tras moverse).
        NodoDecision hojaNoAtacar = new NodoDecision(ctx ->
            System.out.println("[IA] Enemigo se movió pero el jugador sigue fuera de rango. No ataca.")
        );

        // Tras el movimiento: ¿está en rango?
        // Pregunta interior (rama del "no me muevo").
        NodoDecision preguntaTrasMover = new NodoDecision(
            ctx -> ctx.distancia() <= ctx.rangoAtaque, // condición
            hojaAtacar, // sí → ataca
            hojaNoAtacar // no → no ataca
        );

        // Moverse + evaluar lo anterior.
        NodoDecision moverseYEvaluar = new NodoDecision(
            ctx -> {
                // Realizar el movimiento (igual que en enemigo.realizarTurno).
                int difFila    = ctx.filaJugador    - ctx.filaEnemigo;
                int difColumna = ctx.columnaJugador - ctx.columnaEnemigo;
                int nuevaFila    = ctx.filaEnemigo;
                int nuevaColumna = ctx.columnaEnemigo;
                if (difFila != 0) {
                    nuevaFila = ctx.filaEnemigo + Integer.signum(difFila);
                } else {
                    nuevaColumna = ctx.columnaEnemigo + Integer.signum(difColumna);
                }
                int distTras = Math.abs(nuevaFila - ctx.filaJugador) + Math.abs(nuevaColumna - ctx.columnaJugador);
                if (distTras >= ctx.rangoAtaque) {
                    // Movimiento válido: nos deja a rango o más lejos.
                    ctx.enemigo.mover(nuevaFila, nuevaColumna);
                    // Actualizamos el contexto para que la siguiente pregunta
                    // use la posición correcta del enemigo.
                    ctx.filaEnemigo    = nuevaFila;
                    ctx.columnaEnemigo = nuevaColumna;
                    System.out.println("[IA] Enemigo se mueve a (" + nuevaFila + ", " + nuevaColumna + ").");
                    return true;
                } else {
                    // El movimiento nos pondría encima del jugador, y entonces no nos movemos.
                    ctx.enemigo.marcarMovimientoConsumido();
                    System.out.println("[IA] Enemigo ya está en posición óptima. No se mueve.");
                    // Vamos igualmente a preguntaTrasMover (la distancia actual ya puede ser <= rango si estábamos muy cerca).
                    return true; // siempre vamos al hijo "sí" = preguntaTrasMover
                }
            },
            preguntaTrasMover,  // hijo sí (siempre se llega aquí tras el movimiento)
            preguntaTrasMover   // hijo no (mismo nodo: el movimiento siempre "acaba")
        );

        // ¿Está en rango sin moverse?
        NodoDecision preguntaRangoInicial = new NodoDecision(
            ctx -> ctx.distancia() <= ctx.rangoAtaque,
            hojaAtacar, // sí -> atacar sin moverse
            moverseYEvaluar // no -> moverse y reevaluar
        );

        this.raiz = preguntaRangoInicial;
    }



    // Metodo para llevarlo a cabo.
    public void ejecutar(ContextoEnemigo ctx) {
        NodoDecision actual = raiz;
        while (actual != null) {
            if (actual.esHoja()) {
                // Nodo hoja: ejecutar la acción y terminar.
                actual.accion.ejecutar(ctx);
                return;
            }
            // Nodo interior: evaluar la condición y bajar por la rama correcta.
            boolean resultado = actual.pregunta.evaluar(ctx);
            actual = resultado ? actual.hijoSi : actual.hijoNo;
        }
    }
}
