package juego.personajes;

import juego.objetos.objeto;
import juego.objetos.arma;
import juego.objetos.armadura;
import juego.objetos.pocion;
import juego.estructuras.Lista_CDE.Lista_EfectosActivos;
import juego.estructuras.Lista_CDE.Lista_EfectosActivos.EfectoActivo;
import juego.estructuras.ArbolDecision.ArbolDecisionEnemigo;

import static java.lang.Math.max;

public class jugador extends personaje implements ArbolDecisionEnemigo.ObjetivoAtacable {

    private inventario inventario;
    private equipamiento equipo;
    private boolean veneno;
    private boolean congelado;
    private Lista_EfectosActivos efectosActivos = new Lista_EfectosActivos();

    public jugador() { // Son los stats base y el espacio del inventario y el equipamiento.
        super(100, 10, 5, 3, 1);
        inventario = new inventario();
        equipo     = new equipamiento();
    }

    public void curar(int cantidad) {
        vida = Math.min(100, vida + cantidad);
    }

    public boolean tieneVeneno() { return veneno;}
    public boolean estaCongelado() { return congelado;}
    public void setVeneno(boolean v) { veneno = v;}
    public void setCongelado(boolean v) {
        if (v && !congelado) velocidad -= 1; // Si te congelas.
        else if (!v && congelado) velocidad += 1; // Si te descongelas.
        congelado = v;
        if (velocidad == 0) velocidad = 1; // Medida preventiva para que el jugador pueda seguir moviéndose
    }

    public void aplicarBuffAtaque(int bonus, int turnos)   { efectosActivos.add(new EfectoActivo("ataque", bonus, turnos)); }
    public void aplicarBuffDefensa(int bonus, int turnos)  { efectosActivos.add(new EfectoActivo("defensa", bonus, turnos)); }
    public void aplicarBuffVelocidad(int bonus, int turnos){ efectosActivos.add(new EfectoActivo("velocidad", bonus, turnos)); }
    public void reducirDuracionBuffs() { efectosActivos.tick(); }

    public Lista_EfectosActivos getEfectosActivos() { return efectosActivos; }

    @Override
    public int getAtaque() { return ataque + efectosActivos.getTotalBonus("ataque") + equipo.bonusAtaqueTotal();}
    @Override
    public int getDefensa() { return defensa + efectosActivos.getTotalBonus("defensa") + equipo.bonusDefensaTotal();}
    @Override
    public int getVelocidad() { return max(1, velocidad + efectosActivos.getTotalBonus("velocidad") + equipo.bonusVelocidadTotal());} // El jugador tiene como mínimo 1 de velocidad para evitar que se quede atascado

    public void addItem(objeto o) { inventario.add(o);}
    public inventario getInventario() { return inventario;}

    public int getAtaqueInventario()  { return maxAtaqueInventario(); }
    public int getDefensaInventario() { return maxDefensaInventario();}

    public void faseInventario(objeto o) { // Método para ver lo que se hace al seleccionar algo y te lo equipas.
        if (o instanceof arma a) {
            arma anterior = a.getNombre().equalsIgnoreCase("escudo")
                    ? equipo.getEscudo()
                    : equipo.getArma();
            if (anterior != null) inventario.add(anterior);
            equipar(o);
            inventario.remove(o);
        } else if (o instanceof armadura ar) {
            armadura anterior = obtenerArmaduraEquipada(ar.getNombre());
            if (anterior != null) inventario.add(anterior);
            equipar(o);
            inventario.remove(o);
        }
        haUsadoInventario = true;
    }

    public void fasePociones(pocion p) { // Metodo para ver lo que hace la poción que te tomas.
        if (p.getCuraVida() > 0) curar(p.getCuraVida());
        if (p.getBonusAtaque() > 0) aplicarBuffAtaque(p.getBonusAtaque(), p.getDuracionTurnos());
        if (p.getBonusDefensa() > 0) aplicarBuffDefensa(p.getBonusDefensa(), p.getDuracionTurnos());
        if (p.getBonusVelocidad() > 0) aplicarBuffVelocidad(p.getBonusVelocidad(), p.getDuracionTurnos());
        if (p.quitaVeneno()) setVeneno(false);
        if (p.quitaCongelacion()) setCongelado(false);
        inventario.remove(p);
    }

    private armadura obtenerArmaduraEquipada(String nombre) { // Metodo para ver lo que se tiene equipado.
        switch (nombre.toLowerCase()) {
            case "yelmo": return equipo.getYelmo();
            case "coraza": return equipo.getCoraza();
            case "grebas": return equipo.getGrebas();
            case "sabaton": return equipo.getSabaton();
            default: return null;
        }
    }

    public int maxAtaqueInventario() { // Para equilibrar al enemigo.
        int max = 0;
        for (int i = 0; i < inventario.getSize(); i++) {
            if (inventario.get(i) instanceof arma a) max = max(max, a.getBonusAtaque());
        }
        if (equipo.getArma() != null) max = max(max, equipo.getArma().getBonusAtaque());
        return max;
    }

    public int maxDefensaInventario() { // Para equilibrar al enemigo.
        int max = 0;
        for (int i = 0; i < inventario.getSize(); i++) {
            objeto o = inventario.get(i);
            if (o instanceof armadura a)  max = max(max, a.getBonusDefensa());
            else if (o instanceof arma a && a.getNombre().equalsIgnoreCase("escudo"))
                max = max(max, a.getBonusDefensa());
        }
        if (equipo.getEscudo() != null) max = max(max, equipo.getEscudo().getBonusDefensa());
        return max;
    }

    @Override
    public void realizarTurno() {
        // Controlado por JuegoController.
    }

    public equipamiento getEquipo() { return equipo; }

    public void equipar(objeto o) { // Metodo para equiparse algo.
        if (o instanceof arma a) {
            String n = a.getNombre().toLowerCase();
            if (n.equals("espada") || n.equals("hacha") || n.equals("arco")) equipo.equiparArma(a);
            else if (n.equals("escudo")) equipo.equiparEscudo(a);
        } else if (o instanceof armadura ar) {
            switch (ar.getNombre().toLowerCase()) {
                case "yelmo"  -> equipo.equiparYelmo(ar);
                case "coraza" -> equipo.equiparCoraza(ar);
                case "grebas" -> equipo.equiparGrebas(ar);
                case "sabaton"-> equipo.equiparSabaton(ar);
            }
        }
    }
}
