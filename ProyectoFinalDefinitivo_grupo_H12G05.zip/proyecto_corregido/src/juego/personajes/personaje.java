package juego.personajes;

public abstract class personaje {

    protected int vida; // Los stats de los personajes.
    protected int ataque;
    protected int defensa;
    protected int velocidad;
    protected int tipo;

    protected int fila; // Posición en la matriz.
    protected int columna;

    protected int ultFila; // Última posición en la matriz
    protected int ultColumna;

    protected boolean haMovido; // MArcadores de los turnos.
    protected boolean haUsadoInventario;
    protected boolean haActuado;

    public personaje(int v,int a,int d,int vel,int tip){
        vida = v;
        ataque = a;
        defensa = d;
        velocidad = vel;
        tipo = tip;
    }

    public void resetTurno(){ // Metodo para resetear el turno cuando todos hayan hecho lo que tuviesen que hacer.
        haMovido = false;
        haUsadoInventario = false;
        haActuado = false;
    }

    public boolean estaVivo(){
        return vida>0;
    } // Si tiene vida positiva, está vivo.

    // Getters.
    public int getVida(){ return vida;}
    public int getAtaque(){ return ataque;}
    public int getDefensa(){ return defensa;}
    public int getVelocidad(){ return velocidad;}
    public int getTipo(){ return tipo;}


    // Metodo para hacer que la vida del personaje se reduzca.
    public void recibirDaño(int dmg){
        vida -= dmg;
        if(vida<0) vida=0;
    }



    public void mover(int f,int c){ // Metodo para moverse.
        fila = f;
        columna = c;
        haMovido = true;
    }

    // Getters.
    public int getFila(){return fila;}
    public int getColumna(){return columna;}
    public int getUltFila(){return ultFila;}
    public int getUltColumna(){return ultColumna;}
    // Metodo para cambiar la posición del personaje.
    public void setPosicion(int fila, int columna) {
        this.ultFila = this.fila;
        this.ultColumna = this.columna;
        this.fila = fila;
        this.columna = columna;
    }
    public void setFila(int fila) {
        this.ultFila = this.fila;
        this.fila = fila;
    }
    public void setColumna(int columna) {
        this.ultColumna = this.columna;
        this.columna = columna;
    }

    public abstract void realizarTurno();



}