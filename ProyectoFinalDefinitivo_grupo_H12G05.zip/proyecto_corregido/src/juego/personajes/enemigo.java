package juego.personajes;

import juego.objetos.arma;
import juego.objetos.objeto;
import juego.objetos.creadorObjetos;
import juego.estructuras.ArbolDecision.ArbolDecisionEnemigo;

public class enemigo extends personaje
        implements ArbolDecisionEnemigo.ObjetivoAtacable,
        ArbolDecisionEnemigo.MovibleEnemigo, Comparable<enemigo> {

    private jugador objetivo;
    private arma armaEquipada;

    private final ArbolDecisionEnemigo arbolDecision = new ArbolDecisionEnemigo();

    private java.util.function.BiPredicate<Integer, Integer> celdaLibre = (f, c) -> true;

    public void setCeldaLibre(java.util.function.BiPredicate<Integer, Integer> pred) {
        this.celdaLibre = pred;
    }

    public enemigo(String tipo, jugador j) {
        super(
                tipo.equals("debil") ? rnd(30, 50)  : rnd(60, 100), // vida.
                tipo.equals("debil") ? rnd(5, 8)    : rnd(10, 15), // ataque.
                tipo.equals("debil") ? rnd(2, 4)    : rnd(5, 8), // defensa.
                tipo.equals("debil") ? 2            : 3, // velocidad.
                tipo.equals("debil") ? 4            : 5 // tipo.
        );

        this.objetivo = j;
        // Se modifica el valor de la defensa y del ataque del enemigo según lo que haya en el inventario y equipamiento para que esté más nivelado.
        this.ataque  += j.maxAtaqueInventario() / 2;
        this.defensa += j.maxDefensaInventario() / 2;

        creadorObjetos creador = new creadorObjetos();
        String[] armas = {"espada", "hacha", "arco"};
        String nombreArma = armas[rnd(0, armas.length - 1)];
        objeto o = creador.crearObjeto(nombreArma);
        if (o instanceof arma a) {
            this.armaEquipada = a;
            this.ataque += a.getBonusAtaque();
        }
    }

    private static int rnd(int a, int b) {
        return a + (int) (Math.random() * (b - a + 1));
    }

    private int getRangoAtaque() {
        return (armaEquipada != null) ? armaEquipada.getAlcance() : 1;
    }


    @Override
    public void recibirDaño(int cantidad) {
        super.recibirDaño(cantidad);
    }


    @Override
    public void mover(int nuevaFila, int nuevaColumna) {
        if (celdaLibre.test(nuevaFila, nuevaColumna)) {
            super.mover(nuevaFila, nuevaColumna);
        } else {
            haMovido = true; // marcar el movimimiento aunque no lo haya hecho.
        }
    }

    @Override
    public void marcarMovimientoConsumido() {
        haMovido = true;
    }


    @Override
    public void realizarTurno() { // IA del enemigo.
        ArbolDecisionEnemigo.ContextoEnemigo ctx =
                new ArbolDecisionEnemigo.ContextoEnemigo(fila, columna, objetivo.getFila(), objetivo.getColumna(), getRangoAtaque(), ataque, objetivo.getDefensa(),
                        objetivo,   // jugador implementa ObjetivoAtacable
                        this        // this implementa MovibleEnemigo
                );
        arbolDecision.ejecutar(ctx);
        this.fila = ctx.filaEnemigo;
        this.columna = ctx.columnaEnemigo;
        haActuado = true;
    }

    @Override
    public int compareTo(enemigo o) {
        return 0;
    }
}
