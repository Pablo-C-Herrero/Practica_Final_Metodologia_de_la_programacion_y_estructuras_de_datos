package juego.Apartado_visual;

import java.util.List;

/**
 * POJO plano que representa el estado completo de una partida guardada.
 * Gson lo serializa/deserializa automáticamente a/desde JSON.
 */
public class EstadoPartida {

    // ---- Información meta ----
    public String nombrePartida;
    public String fechaGuardado;

    // ---- Stats del jugador ----
    public int jugadorVida;
    public int jugadorAtaqueBase;
    public int jugadorDefensaBase;
    public int jugadorVelocidadBase;
    public int jugadorFila;
    public int jugadorColumna;
    public boolean jugadorVeneno;
    public boolean jugadorCongelado;

    // ---- Efectos activos (buffs/debuffs) ----
    public List<EfectoDTO> efectosActivos;

    // ---- Inventario ----
    public List<ObjetoDTO> inventario;

    // ---- Equipamiento ----
    public ObjetoDTO equipoArma;
    public ObjetoDTO equipoEscudo;
    public ObjetoDTO equipoYelmo;
    public ObjetoDTO equipoCoraza;
    public ObjetoDTO equipoGrebas;
    public ObjetoDTO equipoSabaton;

    // ---- Sala actual (índice en el grafo) ----
    public int indiceSalaActual;
    public int totalSalas;
    public int puertaFila;
    public int puertaColumna;
    public boolean puertaLlave;
    public int puertaTipo;

    // ---- Matriz de la sala actual (filas x columnas) ----
    public int filasSala;
    public int columnasSala;
    public int[][] celdas; // celdas[fila][col]

    // ---- Enemigos en la sala ----
    public List<EnemigoDTO> enemigos;

    // ---- Fase del turno ----
    public String faseActual; // "MOVIMIENTO", "INVENTARIO", "ACCION", "ESPERA_ENEMIGOS"

    // ---- Turnos restantes ----
    public int numTurnos;

    // ---- Log de partida (PilaLog — del más nuevo al más antiguo) ----
    public List<String> logPartida;

    // ---- Ruta comprada ----
    public boolean rutaComprada;

    // =========================================================================
    // DTOs internos (clases de datos planas)
    // =========================================================================

    public static class EfectoDTO {
        public String tipo;
        public int bonus;
        public int duracionRestante;

        public EfectoDTO() {}
        public EfectoDTO(String tipo, int bonus, int duracionRestante) {
            this.tipo = tipo;
            this.bonus = bonus;
            this.duracionRestante = duracionRestante;
        }
    }

    public static class ObjetoDTO {
        /** "arma", "armadura", "pocion", "llave", "moneda", "trampa" */
        public String clase;
        public String nombre;
        public String descripcion;
        public int bonusAtaque;
        public int bonusDefensa;
        public int bonusVelocidad;
        public int penalizacionVelocidad;
        public int penalizacionDefensa;
        public int curaVida;
        public int duracionTurnos;
        public int alcance;          // solo arma
        public boolean quitaVeneno;  // solo pocion
        public boolean quitaCongelacion; // solo pocion
        public String efectoTrampa;  // solo trampa
        public int danoPorTurno;     // solo trampa

        public ObjetoDTO() {}
    }

    public static class EnemigoDTO {
        public int vida;
        public int ataque;
        public int defensa;
        public int velocidad;
        public int fila;
        public int columna;
        public boolean vivo;
        public String tipoArma; // nombre del arma que lleva
        public int alcanceArma;

        public EnemigoDTO() {}
    }
}
