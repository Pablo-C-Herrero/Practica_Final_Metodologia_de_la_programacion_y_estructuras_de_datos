package juego.Apartado_visual;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PantallaTituloController { // Pantalla título

    @FXML private Button salirButton;

    @FXML
    protected void onJugarButtonClick() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(PracticaFinal.class.getResource("/juego/Apartado_visual/game-view.fxml")); // Comenzar Juego
            Stage jugar = new Stage(); // Nueva pantalla
            Scene scene = new Scene(fxmlLoader.load(), 1100, 700); // Definir resolución
            jugar.setTitle("Dungeon RPG"); // Nombre título
            jugar.setScene(scene); // Cargar escena
            jugar.show(); // Mostrar escena
            onSalirButtonClick(); // cerrar pantalla de título
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onCargarPartidaButtonClick() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(PracticaFinal.class.getResource("/juego/Apartado_visual/cargar-partida-view.fxml")); // Buscar archivos de guardado
            Stage cargar = new Stage(); // Nueva pantalla
            Scene scene = new Scene(fxmlLoader.load(), 440, 480); // Definir resolución
            cargar.setTitle("Dungeon RPG — Cargar Partida"); // Nombre título
            cargar.setScene(scene); // Cargar escena
            cargar.show(); // Mostrar escena
            onSalirButtonClick(); // cerrar pantalla de título
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onSalirButtonClick() {
        Stage stage = (Stage) salirButton.getScene().getWindow();
        stage.close(); // Salir del programa
    }
}
