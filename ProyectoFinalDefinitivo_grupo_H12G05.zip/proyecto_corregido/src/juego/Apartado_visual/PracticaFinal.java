package juego.Apartado_visual;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class PracticaFinal extends Application { // Lanzador del juego

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(PracticaFinal.class.getResource("title-view.fxml")); // Definir escena
        Scene scene = new Scene(fxmlLoader.load(), 900, 600); // Definir resolución
        stage.setTitle("Dungeon RPG"); // Definir título
        stage.setScene(scene); // Cargar escena
        stage.show(); // Mostrar escena
    }

    public static void main(String[] args) {
        launch();
    }
}
