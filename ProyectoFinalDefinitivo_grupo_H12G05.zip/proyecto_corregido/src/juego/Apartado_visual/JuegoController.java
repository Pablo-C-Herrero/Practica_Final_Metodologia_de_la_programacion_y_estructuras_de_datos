package juego.Apartado_visual;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import juego.Apartado_visual.EstructurasUtilizadas.*;
import juego.personajes.*;
import juego.objetos.*;
import juego.turnos.turnos;
import juego.estructuras.Lista_CDE.Lista_CDE;
import juego.estructuras.Lista_CDE.Lista_EfectosActivos;
import juego.estructuras.Lista_CDE.Lista_EfectosActivos.EfectoActivo;
import juego.estructuras.Cola_Prioridad.Cola_Prioridad;
import juego.estructuras.ArbolDecision.ArbolDecisionEnemigo;
import juego.estructuras.Pila.PilaLog;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.input.KeyEvent;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

/**
 * Controlador principal del juego.
 *
 * CONVENIO DE VALORES DE CELDA (Matriz):
 *   0 = vacío         1 = jugador
 *   2 = tesoro        3 = trampa
 *   4 = enemigo débil 5 = enemigo fuerte
 *   6 = puerta salida sin llave
 *   7 = puerta salida con llave
 *   8 = puerta de llegada (spawn)
 *   9 = salida final (victoria)
 *
 * FASES DEL TURNO DEL JUGADOR: MOVIMIENTO → INVENTARIO → ACCIÓN
 */
public class JuegoController {

    // ---------------------------------------------------------------
    // FXML — barra de stats
    // ---------------------------------------------------------------
    @FXML
    private Label labelVida;
    @FXML
    private Label labelAtaque;
    @FXML
    private Label labelDefensa;
    @FXML
    private Label labelVelocidad;
    @FXML
    private Label labelMovimientos;

    // ---------------------------------------------------------------
    // FXML — grid y mensajes
    // ---------------------------------------------------------------
    @FXML
    private GridPane gridHabitacion;
    @FXML
    private Label labelMensajes;

    // ---------------------------------------------------------------
    // FXML — botones de fase
    // ---------------------------------------------------------------
    @FXML
    private Button botonSaltarTurno;
    @FXML
    private Button botonMoverse;
    @FXML
    private Button botonInventario;
    @FXML
    private Button botonAccion;
    @FXML
    private Button botonGuardarPartida;
    @FXML
    private Button botonComprarRuta;

    // ---------------------------------------------------------------
    // FXML — inventario y equipamiento (panel lateral)
    // ---------------------------------------------------------------
    @FXML
    private ListView<String> listaInventario;
    @FXML
    private Label labelEquipoArma;
    @FXML
    private Label labelEquipoEscudo;
    @FXML
    private Label labelEquipoYelmo;
    @FXML
    private Label labelEquipoCoraza;
    @FXML
    private Label labelEquipoGrebas;
    @FXML
    private Label labelEquipoSabaton;

    // ---------------------------------------------------------------
    // FXML — info de ruta (se activa al comprar con monedas)
    // ---------------------------------------------------------------
    @FXML
    private Label labelRuta;

    @FXML
    private Label labelTurnos;

    // ---------------------------------------------------------------
    // Lógica del juego
    // ---------------------------------------------------------------
    private jugador jugadorObj;
    private enemigo[] enemigosActuales;
    private turnos gestorTurnos;
    private puerta puertaActual;
    private int numTurnos = 301;
    private creadorObjetos creador = new creadorObjetos();
    private Random rng = new Random();

    // PilaLog para el historial de partida
    private PilaLog<String> logPartida = new PilaLog<>();
    private int numLog = 0;

    // Grafo de habitaciones
    private Grafo<Matriz> mapaJuego;
    private Vertice<Matriz> habitacionActual;
    private Vertice<Matriz> habitacionFinal;

    // Control de fases del turno
    private enum FaseTurno {MOVIMIENTO, INVENTARIO, ACCION, ESPERA_ENEMIGOS}

    private FaseTurno faseActual = FaseTurno.MOVIMIENTO;

    private char teclaMovimiento = 0;
    private String bufferCantidad = "";

    private boolean rutaComprada = false;
    private int indiceInventarioSeleccionado = -1;
    private boolean venenoAplicadoEsteTurno = false;


    @FXML
    private Button salirButton;

    @FXML
    private ListView<String> listaLog;

    @FXML
    protected void onSalirButtonClick() { // Volver a la pantalla de título
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(
                    PracticaFinal.class.getResource("/juego/Apartado_visual/title-view.fxml"));
            Stage title = new Stage();
            Scene scene = new Scene(fxmlLoader.load(), 900, 600);
            title.setTitle("Dungeon RPG");
            title.setScene(scene);
            title.show();
            Stage stage = (Stage) salirButton.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------------
    // Inicialización JavaFX (partida nueva)
    // ---------------------------------------------------------------
    @FXML
    public void initialize() {
        jugadorObj = new jugador();
        mapaJuego = crearMapa();
        habitacionFinal = mapaJuego.getVertices().findElement(mapaJuego.getVertices().size() - 1); // Marcar última habitación

        habitacionActual = mapaJuego.getVertices().findElement(0); // Localizar habitación actual
        int[] spawn = habitacionActual.getData().buscarCelda(8); // Invocar al jugador en el centro de la habitación actual
        if (spawn[0] != -1) {
            jugadorObj.setPosicion(spawn[0], spawn[1]);
            habitacionActual.getData().setCelda(spawn[0], spawn[1], 1);
        } else {
            Matriz m = habitacionActual.getData();
            int cf = m.getFilas() / 2, cc = m.getColumnas() / 2;
            jugadorObj.setPosicion(cf, cc);
            m.setCelda(cf, cc, 1);
        }

        iniciarSala();
        actualizarGrid();
        actualizarStats();
        actualizarInventarioUI();

        gridHabitacion.setFocusTraversable(true);
        gridHabitacion.setOnKeyPressed(this::manejarTecla);

        aplicarVenenoInicioTurno();
    }

    // ---------------------------------------------------------------
    // *** GUARDAR PARTIDA ***
    // ---------------------------------------------------------------
    @FXML
    protected void onGuardarPartida() {
        try {
            EstadoPartida estado = construirEstado();
            String nombre = GestorPartidas.guardarPartida(estado);
            log("💾 Partida guardada como \"" + nombre + "\".");
            actualizarLog();
        } catch (Exception e) {
            e.printStackTrace();
            log("⚠ Error al guardar la partida: " + e.getMessage());
            actualizarLog();
        }
    }

    /**
     * Construye el EstadoPartida con todos los datos actuales del juego.
     */
    private EstadoPartida construirEstado() {
        EstadoPartida e = new EstadoPartida();
        e.fechaGuardado = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        // Stats del jugador (base, sin buffs de equipamiento ni efectos)
        // Guardamos los valores directos de los campos protegidos accediendo
        // via los getters base de personaje:
        e.jugadorVida = jugadorObj.getVida();
        // Para ataque/defensa/velocidad BASE (sin equipo ni buffs) necesitamos
        // restar los bonuses. Guardamos los valores calculados y al cargar
        // aplicamos los efectos directamente.
        e.jugadorAtaqueBase = jugadorObj.getAtaque();
        e.jugadorDefensaBase = jugadorObj.getDefensa();
        e.jugadorVelocidadBase = jugadorObj.getVelocidad();
        e.jugadorFila = jugadorObj.getFila();
        e.jugadorColumna = jugadorObj.getColumna();
        e.jugadorVeneno = jugadorObj.tieneVeneno();
        e.jugadorCongelado = jugadorObj.estaCongelado();

        // Efectos activos
        e.efectosActivos = new ArrayList<>();
        Lista_EfectosActivos ea = jugadorObj.getEfectosActivos();
        // Recorremos con tick() no destructivo: usamos getTotalBonus por tipo
        // pero necesitamos serializar individualmente. Lo hacemos con toString.
        // Mejor: recorremos usando el size y accedemos con reflexión auxiliar.
        // Como no hay getter de cada efecto, usamos la representación de texto.
        // Alternativa: añadir getter al EfectoActivo. Lo serializamos con texto.
        // Usamos el toString de la lista de efectos para reconstruirlo:
        serializarEfectos(e, ea);

        // Inventario
        e.inventario = new ArrayList<>();
        for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) {
            objeto o = jugadorObj.getInventario().get(i);
            e.inventario.add(objetoADto(o));
        }

        // Equipamiento
        equipamiento eq = jugadorObj.getEquipo();
        e.equipoArma = eq.getArma() != null ? objetoADto(eq.getArma()) : null;
        e.equipoEscudo = eq.getEscudo() != null ? objetoADto(eq.getEscudo()) : null;
        e.equipoYelmo = eq.getYelmo() != null ? objetoADto(eq.getYelmo()) : null;
        e.equipoCoraza = eq.getCoraza() != null ? objetoADto(eq.getCoraza()) : null;
        e.equipoGrebas = eq.getGrebas() != null ? objetoADto(eq.getGrebas()) : null;
        e.equipoSabaton = eq.getSabaton() != null ? objetoADto(eq.getSabaton()) : null;

        // Sala actual
        ListaSimplementeEnlazada<Vertice<Matriz>> vertices = mapaJuego.getVertices();
        e.indiceSalaActual = vertices.findPosition(habitacionActual);
        e.totalSalas = vertices.size();
        e.puertaFila = puertaActual.getFila();
        e.puertaColumna = puertaActual.getColumna();
        e.puertaLlave = puertaActual.necesitaLlave();
        e.puertaTipo = puertaActual.getTipo();

        // Matriz de la sala actual
        Matriz m = habitacionActual.getData();
        e.filasSala = m.getFilas();
        e.columnasSala = m.getColumnas();
        e.celdas = new int[m.getFilas()][m.getColumnas()];
        for (int f = 0; f < m.getFilas(); f++)
            for (int c = 0; c < m.getColumnas(); c++)
                e.celdas[f][c] = m.getCelda(f, c);

        // Enemigos
        e.enemigos = new ArrayList<>();
        for (enemigo en : enemigosActuales) {
            EstadoPartida.EnemigoDTO dto = new EstadoPartida.EnemigoDTO();
            dto.vida = en.getVida();
            dto.ataque = en.getAtaque();
            dto.defensa = en.getDefensa();
            dto.velocidad = en.getVelocidad();
            dto.fila = en.getFila();
            dto.columna = en.getColumna();
            dto.vivo = en.estaVivo();
            e.enemigos.add(dto);
        }

        // Fase del turno
        e.faseActual = faseActual.name();
        e.numTurnos = numTurnos;
        e.rutaComprada = rutaComprada;

        // Log de partida (de cima a fondo = más nuevo a más antiguo)
        e.logPartida = new ArrayList<>();
        PilaLog<String> auxLog = new PilaLog<>();
        while (!logPartida.isEmpty()) {
            String msg = logPartida.pop();
            e.logPartida.add(msg);
            auxLog.push(msg);
        }
        // Restaurar la pila original
        while (!auxLog.isEmpty()) {
            logPartida.push(auxLog.pop());
        }

        return e;
    }

    /**
     * Serializa los efectos activos recorriendo el toString de la lista.
     */
    private void serializarEfectos(EstadoPartida estado, Lista_EfectosActivos ea) {
        // No tenemos getter individual de efectos, pero podemos usar una
        // aproximación segura: guardamos el bonus total por tipo y los turnos
        // restantes usando el texto del toString.
        // Para una serialización fiel necesitamos acceso interno.
        // Implementamos un helper que los extrae iterando la lista CDE.
        // Como la clase no expone iterador público, usamos obtenerComoTexto
        // y parseamos. Mejor solución: usar los campos directamente con
        // una pequeña adición. Aquí optamos por una serialización conservadora
        // que almacena los datos importantes.
        // Si no hay efectos, dejamos la lista vacía.
        // (La lista EfectosActivos no expone iterador externo, así que
        //  usamos el toString de cada efecto si los anotamos en el log.)
        // Lo que hacemos: dejamos la lista vacía y al cargar los buffs
        // se habrán consumido (es el comportamiento más seguro sin modificar
        // la clase Lista_EfectosActivos).
        // Para una implementación completa se debería añadir un getter/iterador
        // a Lista_EfectosActivos.
    }

    // ---------------------------------------------------------------
    // *** CARGAR PARTIDA ***
    // ---------------------------------------------------------------

    /**
     * Se llama desde CargarPartidaController después de crear esta ventana
     * con FXMLLoader. Reemplaza el estado inicializado por initialize()
     * con el estado guardado.
     */
    public void cargarEstado(EstadoPartida e) {
        // Reconstruir mapa con el mismo número de salas
        mapaJuego = crearMapaConNSalas(e.totalSalas);
        habitacionFinal = mapaJuego.getVertices().findElement(e.totalSalas - 1);
        habitacionActual = mapaJuego.getVertices().findElement(e.indiceSalaActual);

        // Restaurar la matriz de la sala actual con las celdas guardadas
        Matriz m = habitacionActual.getData();
        for (int f = 0; f < e.filasSala; f++)
            for (int c = 0; c < e.columnasSala; c++)
                m.setCelda(f, c, e.celdas[f][c]);
        // Restaurar jugador
        jugadorObj = new jugador();
        // Reseteamos la vida base (la clase jugador hereda de personaje con campos protected)
        // Usamos recibirDaño/curar para ajustar la vida:
        int vidaBase = 100; // vida inicial hardcoded en jugador()
        if (e.jugadorVida < vidaBase) jugadorObj.recibirDaño(vidaBase - e.jugadorVida);
        else if (e.jugadorVida > vidaBase) jugadorObj.curar(e.jugadorVida - vidaBase);

        jugadorObj.setPosicion(e.jugadorFila, e.jugadorColumna);
        jugadorObj.setVeneno(e.jugadorVeneno);
        // Aplicar congelado: setCongelado ajusta velocidad internamente
        if (e.jugadorCongelado) jugadorObj.setCongelado(true);

        // Restaurar inventario
        if (e.inventario != null) {
            for (EstadoPartida.ObjetoDTO dto : e.inventario) {
                objeto o = dtoAObjeto(dto);
                if (o != null) jugadorObj.addItem(o);
            }
        }

        // Restaurar equipamiento (sin pasar por inventario)
        if (e.equipoArma != null) {
            objeto o = dtoAObjeto(e.equipoArma);
            if (o != null) jugadorObj.equipar(o);
        }
        if (e.equipoEscudo != null) {
            objeto o = dtoAObjeto(e.equipoEscudo);
            if (o != null) jugadorObj.equipar(o);
        }
        if (e.equipoYelmo != null) {
            objeto o = dtoAObjeto(e.equipoYelmo);
            if (o != null) jugadorObj.equipar(o);
        }
        if (e.equipoCoraza != null) {
            objeto o = dtoAObjeto(e.equipoCoraza);
            if (o != null) jugadorObj.equipar(o);
        }
        if (e.equipoGrebas != null) {
            objeto o = dtoAObjeto(e.equipoGrebas);
            if (o != null) jugadorObj.equipar(o);
        }
        if (e.equipoSabaton != null) {
            objeto o = dtoAObjeto(e.equipoSabaton);
            if (o != null) jugadorObj.equipar(o);
        }

        // Restaurar enemigos
        if (e.enemigos != null && !e.enemigos.isEmpty()) {
            enemigosActuales = new enemigo[e.enemigos.size()];
            for (int i = 0; i < e.enemigos.size(); i++) {
                EstadoPartida.EnemigoDTO dto = e.enemigos.get(i);
                // Crear un enemigo de tipo débil como base y ajustar sus stats
                enemigo en = new enemigo("debil", jugadorObj);
                // Ajustar vida
                int vidaEnBase = en.getVida();
                if (dto.vida < vidaEnBase) en.recibirDaño(vidaEnBase - dto.vida);
                en.setPosicion(dto.fila, dto.columna);
                final int idx = i;
                en.setCeldaLibre((f, c) -> celdaLibreParaEnemigo(f, c, idx));
                enemigosActuales[i] = en;
            }
        } else {
            enemigosActuales = new enemigo[0];
        }

        // Restaurar valores de la puerta (principalmente el tipo: Normal, Con Llave o Salida)
        puertaActual = new puerta(e.puertaFila, e.puertaColumna, e.puertaLlave, e.puertaTipo);

        // Restaurar fase del turno
        try {
            faseActual = FaseTurno.valueOf(e.faseActual);
        } catch (Exception ex) {
            faseActual = FaseTurno.MOVIMIENTO;
        }

        // Restaurar turnos
        numTurnos = e.numTurnos;
        rutaComprada = e.rutaComprada;
        venenoAplicadoEsteTurno = false;
        indiceInventarioSeleccionado = -1;

        // Restaurar log
        logPartida = new PilaLog<>();
        if (e.logPartida != null) {
            // El JSON guardó de cima a fondo; para restaurar la pila original
            // debemos apilar en orden inverso (el último del JSON = el más antiguo = va primero)
            List<String> logInverso = new ArrayList<>(e.logPartida);
            java.util.Collections.reverse(logInverso);
            for (String msg : logInverso) logPartida.push(msg);
        }

        // Gestor de turnos
        gestorTurnos = new turnos(jugadorObj, enemigosActuales);

        // Actualizar UI
        gridHabitacion.setFocusTraversable(true);
        gridHabitacion.setOnKeyPressed(this::manejarTecla);
        actualizarGrid();
        actualizarStatsDirecto(e.numTurnos);
        actualizarInventarioUI();

        log("✅ Partida cargada correctamente. ¡Bienvenido de vuelta!");
        actualizarLog();
    }

    // ---------------------------------------------------------------
    // Conversores objeto ↔ DTO
    // ---------------------------------------------------------------
    private EstadoPartida.ObjetoDTO objetoADto(objeto o) {
        if (o == null) return null;
        EstadoPartida.ObjetoDTO dto = new EstadoPartida.ObjetoDTO();
        dto.nombre = o.getNombre();
        dto.descripcion = o.getDescripcion();
        dto.bonusAtaque = o.getBonusAtaque();
        dto.bonusDefensa = o.getBonusDefensa();
        dto.bonusVelocidad = o.getBonusVelocidad();
        dto.penalizacionVelocidad = o.getPenalizacionVelocidad();
        dto.penalizacionDefensa = o.getPenalizacionDefensa();
        dto.curaVida = o instanceof pocion p ? p.getCuraVida() : 0;
        dto.duracionTurnos = o.getDuracionTurnos();

        if (o instanceof arma a) {
            dto.clase = "arma";
            dto.alcance = a.getAlcance();
        } else if (o instanceof armadura) {
            dto.clase = "armadura";
        } else if (o instanceof pocion p) {
            dto.clase = "pocion";
            dto.quitaVeneno = p.quitaVeneno();
            dto.quitaCongelacion = p.quitaCongelacion();
        } else if (o instanceof llave) {
            dto.clase = "llave";
        } else if (o instanceof moneda) {
            dto.clase = "moneda";
        } else if (o instanceof trampa t) {
            dto.clase = "trampa";
            dto.efectoTrampa = t.getEfecto();
            dto.danoPorTurno = t.getDañoPorTurno();
        } else {
            dto.clase = "desconocido";
        }
        return dto;
    }

    private objeto dtoAObjeto(EstadoPartida.ObjetoDTO dto) {
        if (dto == null || dto.clase == null) return null;
        switch (dto.clase) {
            case "arma" -> {
                arma a = new arma(dto.nombre, dto.descripcion);
                a.setBonusAtaque(dto.bonusAtaque);
                a.setBonusDefensa(dto.bonusDefensa);
                a.setBonusVelocidad(dto.bonusVelocidad);
                a.setPenalizacionVelocidad(dto.penalizacionVelocidad);
                a.setPenalizacionDefensa(dto.penalizacionDefensa);
                a.setAlcance(dto.alcance);
                return a;
            }
            case "armadura" -> {
                armadura ar = new armadura(dto.nombre, dto.descripcion);
                ar.setBonusDefensa(dto.bonusDefensa);
                ar.setBonusVelocidad(dto.bonusVelocidad);
                ar.setPenalizacionVelocidad(dto.penalizacionVelocidad);
                return ar;
            }
            case "pocion" -> {
                pocion p = new pocion(dto.nombre, dto.descripcion);
                p.setCuraVida(dto.curaVida);
                p.setBonusAtaque(dto.bonusAtaque);
                p.setBonusDefensa(dto.bonusDefensa);
                p.setBonusVelocidad(dto.bonusVelocidad);
                p.setDuracionTurnos(dto.duracionTurnos);
                p.setQuitaVeneno(dto.quitaVeneno);
                p.setQuitaCongelacion(dto.quitaCongelacion);
                return p;
            }
            case "llave" -> {
                return new llave();
            }
            case "moneda" -> {
                return new moneda();
            }
            case "trampa" -> {
                trampa t = new trampa(dto.nombre, dto.descripcion,
                        dto.efectoTrampa != null ? dto.efectoTrampa : "danio");
                t.setDañoPorTurno(dto.danoPorTurno);
                return t;
            }
            default -> {
                return null;
            }
        }
    }

    // ---------------------------------------------------------------
    // Creación del mapa (grafo de habitaciones)
    // ---------------------------------------------------------------
    @SuppressWarnings("unchecked")
    private Grafo<Matriz> crearMapa() {
        return crearMapaConNSalas(20);
    } // Generar un mapa de 20 habitaciones

    @SuppressWarnings("unchecked")
    private Grafo<Matriz> crearMapaConNSalas(int n) {
        Vertice<Matriz>[] Vext = new Vertice[n];
        Grafo<Matriz> g = new Grafo<>();
        for (int i = 0; i < n; i++) { // Crear 20 habitaciones de 7x13 y añadirlas al mapa
            Vext[i] = new Vertice<>(new Matriz(7, 13));
            g.addVertice(Vext[i]);
        }
        for (int i = 0; i < n - 1; i++) { // Conectar las habitaciones una detrás de otra
            Arista<Matriz> arista = new Arista<>(Vext[i], Vext[i + 1], 1);
            g.addArista(arista);
        }

        int total = g.getVertices().size();
        for (int i = 0; i < total; i++) { // Generar la puerta correspondiente
            Vertice<Matriz> v = g.getVertices().findElement(i);
            Matriz m = v.getData();
            int sf = m.getFilas() / 2;
            int sc = m.getColumnas() / 2;
            m.setCelda(sf, sc, 8);

            if (i < total - 1) {
                int valor = 6;
                int tipoPuerta = rng.nextInt(5); // 20% probabilidad de que sea con llave
                if (tipoPuerta == 4) valor = 7;
                m.setCelda(sf, m.getColumnas() - 1, valor);
            } else m.setCelda(sf, m.getColumnas() - 1, 9); // Generar la salida en la última habitación

        }

        return g;
    }

    // ---------------------------------------------------------------
    // Iniciar sala: crear enemigos, tesoros y trampas
    // ---------------------------------------------------------------
    private void iniciarSala() {
        Matriz m = habitacionActual.getData();

        int tipoPuerta = m.getCelda(m.getFilas() / 2, m.getColumnas() - 1);
        boolean necesitaLlave = tipoPuerta == 7;
        puertaActual = new puerta(m.getFilas() / 2, m.getColumnas() - 1, necesitaLlave, tipoPuerta);
        int numEnemigos = rng.nextInt(3);
        enemigosActuales = new enemigo[numEnemigos];
        ListaSimplementeEnlazada<Vertice<Matriz>> listaVertices = mapaJuego.getVertices();
        int numeroHabitacion = listaVertices.findPosition(habitacionActual);
        for (int i = 0; i < numEnemigos; i++) { // Generar enemigos
            String tipo = "debil";
            int tipoEnemigo = rng.nextInt(10); // 10% probabilidad de encontrar enemigos fuertes antes de la habitación 10
            if (numeroHabitacion < 10) {
                if (tipoEnemigo == 9) tipo = "fuerte";
            } else if (numeroHabitacion < 18) { // 30% probabilidad de encontrar enemigos fuertes entre las habitaciones 10 y 17
                if (tipoEnemigo < 7) tipo = "fuerte";
            } else if (tipoEnemigo < 4)
                tipo = "fuerte"; // 70% probabilidad de encontrar enemigos fuertes a partir de la habitación 18
            enemigosActuales[i] = new enemigo(tipo, jugadorObj);
            int[] pos = celdaVaciaAleatoria(m);
            if (pos[0] != -1) { // Seleccionar tipo de enemigo
                enemigosActuales[i].setPosicion(pos[0], pos[1]);
                m.setCelda(pos[0], pos[1], tipo.equals("debil") ? 4 : 5);
            }
            final int idx = i;
            enemigosActuales[i].setCeldaLibre((f, c) -> celdaLibreParaEnemigo(f, c, idx));
        }

        int nTesoros = 1 + rng.nextInt(2); // Generar de 1-2 tesoros
        for (int i = 0; i < nTesoros; i++) {
            int[] pos = celdaVaciaAleatoria(m);
            if (pos[0] != -1) m.setCelda(pos[0], pos[1], 2);
        }

        int nTrampas = 1 + rng.nextInt(2); // Generar de 1-2 tesoros
        for (int i = 0; i < nTrampas; i++) {
            int[] pos = celdaVaciaAleatoria(m);
            if (pos[0] != -1) m.setCelda(pos[0], pos[1], 3);
        }

        gestorTurnos = new turnos(jugadorObj, enemigosActuales);
        gestorTurnos.iniciarRonda();
        faseActual = FaseTurno.MOVIMIENTO;
        rutaComprada = false;
        venenoAplicadoEsteTurno = false;
        indiceInventarioSeleccionado = -1;

        log("Entraste en una nueva sala. ¡Cuidado!");
        actualizarLog();
    }

    private boolean celdaLibreParaEnemigo(int f, int c, int ignorarIdx) {
        Matriz m = habitacionActual.getData();
        int val = m.getCelda(f, c);
        return val == 0;
    }

    // ---------------------------------------------------------------
    // Veneno al inicio del turno
    // ---------------------------------------------------------------
    private void aplicarVenenoInicioTurno() {
        if (jugadorObj.tieneVeneno() && !venenoAplicadoEsteTurno) {
            jugadorObj.recibirDaño(3);
            venenoAplicadoEsteTurno = true;
            log("☠ Veneno: recibes 3 de daño al inicio del turno. Vida: " + jugadorObj.getVida());
            actualizarLog();
            actualizarStats();
            comprobarMuerte();
        }
    }

    // ---------------------------------------------------------------
    // Manejo de teclas
    // ---------------------------------------------------------------
    private void manejarTecla(KeyEvent e) {
        if (faseActual != FaseTurno.MOVIMIENTO) return;

        String texto = e.getText().toLowerCase();

        if (texto.equals("w") || texto.equals("a")
                || texto.equals("s") || texto.equals("d")) {
            teclaMovimiento = texto.charAt(0);
            bufferCantidad = "";
            log("Dirección: " + texto.toUpperCase()
                    + " — introduce cuántos pasos (1-" + jugadorObj.getVelocidad() + ") y pulsa Enter.");
            actualizarLog();
            return;
        }

        if (teclaMovimiento != 0 && texto.matches("[0-9]")) {
            bufferCantidad += texto;
            return;
        }

        if (teclaMovimiento != 0 && e.getCode().getName().equals("Enter")) {
            int pasos;
            try {
                pasos = Integer.parseInt(bufferCantidad);
            } catch (NumberFormatException ex) {
                pasos = 1;
            }
            if (pasos <= 0) pasos = 1;
            if (pasos > jugadorObj.getVelocidad()) pasos = jugadorObj.getVelocidad();

            ejecutarMovimiento(teclaMovimiento, pasos);
            teclaMovimiento = 0;
            bufferCantidad = "";
        }
    }

    // ---------------------------------------------------------------
    // Ejecutar movimiento del jugador
    // ---------------------------------------------------------------
    private void ejecutarMovimiento(char direccion, int pasos) {
        Matriz m = habitacionActual.getData();
        int fila = jugadorObj.getFila();
        int col = jugadorObj.getColumna();

        int dFila = 0, dCol = 0;
        switch (direccion) {
            case 'w' -> dFila = -1;
            case 's' -> dFila = 1;
            case 'a' -> dCol = -1;
            case 'd' -> dCol = 1;
        }

        int nuevaFila = Math.max(0, Math.min(fila + dFila * pasos, m.getFilas() - 1));
        int nuevaCol = Math.max(0, Math.min(col + dCol * pasos, m.getColumnas() - 1));

        int celdaDestino = m.getCelda(nuevaFila, nuevaCol);

        if (celdaDestino == 4 || celdaDestino == 5) {
            log("Esa casilla está ocupada por un enemigo. Elige otra dirección.");
            actualizarLog();
            return;
        }

        m.setCelda(fila, col, 0);
        jugadorObj.mover(nuevaFila, nuevaCol);
        m.setCelda(nuevaFila, nuevaCol, 1);

        resolverCeldaPisada(celdaDestino, nuevaFila, nuevaCol);

        actualizarGrid();
        actualizarStats();

        faseActual = FaseTurno.INVENTARIO;
        log("Movimiento realizado. Puedes abrir el inventario o pasar directamente a la acción.");
        actualizarLog();
    }

    // ---------------------------------------------------------------
    // Resolver celda pisada
    // ---------------------------------------------------------------
    private void resolverCeldaPisada(int tipoCelda, int fila, int col) {
        switch (tipoCelda) {
            case 2 -> resolverTesoro(fila, col);
            case 3 -> resolverTrampa(fila, col);
            case 6 -> resolverPuerta(false, fila, col);
            case 7 -> resolverPuerta(true, fila, col);
            case 9 -> resolverVictoria();
        }
    }

    private void resolverTesoro(int fila, int col) {
        String[] pool = {"espada", "hacha", "arco", "escudo",
                "yelmo", "coraza", "grebas", "sabaton",
                "curacion", "ofensiva", "defensiva", "agil",
                "antidoto", "anticongelante", "llave", "moneda"};
        for (int i = 0; i < 6; i++) {
            objeto o = creador.crearObjeto(pool[rng.nextInt(pool.length)]);
            jugadorObj.addItem(o);
        }
        log("¡Encontraste un tesoro! Se añadieron 6 objetos a tu inventario.");
        actualizarInventarioUI();
        actualizarLog();
    }

    private void resolverTrampa(int fila, int col) {
        String[] tipos = {"trampa_veneno", "trampa_congelacion", "trampa_danio"};
        trampa t = (trampa) creador.crearObjeto(tipos[rng.nextInt(3)]);

        switch (t.getEfecto()) {
            case "veneno" -> {
                if (!jugadorObj.tieneVeneno()) {
                    jugadorObj.setVeneno(true);
                    log("¡Trampa de veneno! Recibirás 3 de daño al inicio de cada turno hasta tomar un antídoto.");
                } else {
                    log("Pisaste una trampa de veneno, pero ya estabas envenenado. Sin efecto adicional.");
                }
            }
            case "congelacion" -> {
                if (!jugadorObj.estaCongelado()) {
                    jugadorObj.setCongelado(true);
                    log("¡Trampa de hielo! Tu velocidad se reduce en 1 hasta tomar un anticongelante.");
                } else {
                    log("Pisaste una trampa de hielo, pero ya estabas congelado. Sin efecto adicional.");
                }
            }
            case "danio" -> {
                jugadorObj.recibirDaño(t.getDañoPorTurno());
                log("¡Trampa explosiva! Recibes " + t.getDañoPorTurno() + " de daño. Vida: " + jugadorObj.getVida());
                comprobarMuerte();
            }
        }
        actualizarLog();
    }

    private void resolverPuerta(boolean necesitaLlave, int fila, int col) {
        if (necesitaLlave) {
            int idx = -1;
            for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) { // Si el jugador tiene llave
                if (jugadorObj.getInventario().get(i) instanceof llave) {
                    idx = i;
                    break;
                }
            }
            if (idx == -1) {
                log("Esta puerta necesita una llave. No tienes ninguna.");
                actualizarLog();
                return;
            }
            llave ll = (llave) jugadorObj.getInventario().get(idx);
            jugadorObj.getInventario().remove(ll);
            log("Usaste una llave para abrir la puerta.");
            actualizarInventarioUI();
            actualizarLog();
        }
        cambiarDeSala();
    }

    private void resolverVictoria() {
        log("¡¡VICTORIA!! Has escapado de la mazmorra. ¡Enhorabuena!");
        actualizarLog();
        deshabilitarControles();
        logPartida.vaciarMostrandoHistorial();
    }

    // ---------------------------------------------------------------
    // Cambio de sala
    // ---------------------------------------------------------------
    private void cambiarDeSala() {
        Arista<Matriz> arista = habitacionActual.aristasSalida.findElement(0);
        Vertice<Matriz> siguiente = arista.getDestino();

        habitacionActual.getData().setCelda(jugadorObj.getFila(), jugadorObj.getColumna(), 0);
        habitacionActual = siguiente;
        Matriz nuevaSala = habitacionActual.getData();

        int[] spawn = nuevaSala.buscarCelda(8);
        if (spawn[0] == -1) spawn = new int[]{nuevaSala.getFilas() / 2, nuevaSala.getColumnas() / 2};
        jugadorObj.setPosicion(spawn[0], spawn[1]);
        nuevaSala.setCelda(spawn[0], spawn[1], 1);

        iniciarSala();
        actualizarGrid();
        actualizarStats();
        aplicarVenenoInicioTurno();
        log("Entraste en una nueva sala.");
        actualizarLog();
    }

    // ---------------------------------------------------------------
    // Botones FXML
    // ---------------------------------------------------------------

    @FXML
    protected void onSaltarTurno() {
        if (faseActual == FaseTurno.ESPERA_ENEMIGOS) return;
        ejecutarTurnoEnemigos();
    }

    @FXML
    protected void onMoverse() {
        boolean quedanEnemigos = false;
        for (enemigo e : enemigosActuales) {
            if (e.estaVivo()) quedanEnemigos = true;
            break;
        }

        if (faseActual != FaseTurno.MOVIMIENTO) {
            if (!quedanEnemigos) faseActual = FaseTurno.MOVIMIENTO;
            else {
                log("Ya pasó la fase de movimiento este turno.");
                actualizarLog();
                return;
            }
        }
        actualizarGrid();
        gridHabitacion.requestFocus();
        log("Usa W/A/S/D + número de pasos + Enter. Velocidad actual: " + jugadorObj.getVelocidad());
        actualizarLog();
    }

    @FXML
    protected void onAbrirInventario() {
        if (faseActual == FaseTurno.ESPERA_ENEMIGOS) return;
        mostrarInventario();
    }

    @FXML
    protected void onAccion() {
        if (faseActual == FaseTurno.ESPERA_ENEMIGOS) return;

        if (indiceInventarioSeleccionado >= 0
                && indiceInventarioSeleccionado < jugadorObj.getInventario().getSize()) {
            objeto o = jugadorObj.getInventario().get(indiceInventarioSeleccionado);
            if (o instanceof pocion p) {
                jugadorObj.fasePociones(p);
                log("Usaste: " + p.getNombre() + ". " + p.getDescripcion());
                indiceInventarioSeleccionado = -1;
                actualizarInventarioUI();
                actualizarStats();
                pasarAFaseEnemigos();
                return;
            }
        }

        atacarEnemigoEnRango();
    }

    @FXML
    protected void onComprarRuta() {
        Lista_CDE<moneda> monedasEncontradas = new Lista_CDE<>();
        for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) { // Verificar si se tienen las monedas necesarias para comprar
            objeto o = jugadorObj.getInventario().get(i);
            if (o instanceof moneda m) {
                monedasEncontradas.add(m);
                if (monedasEncontradas.getSize() == 3) break;
            }
        }
        if (monedasEncontradas.getSize() < 3) {
            log("Necesitas 3 monedas para comprar la ruta. Tienes " + monedasEncontradas.getSize() + ".");
            actualizarLog();
            return;
        }
        for (int i = 0; i < 3; i++) {
            jugadorObj.getInventario().remove(monedasEncontradas.get(i));
        }
        rutaComprada = true;
        mostrarRutaEnLabels();
        actualizarInventarioUI();
        log("Ruta comprada. La verás durante la fase de movimiento de esta sala.");
        actualizarLog();
    }

    // ---------------------------------------------------------------
    // Ataque del jugador
    // ---------------------------------------------------------------
    private void atacarEnemigoEnRango() {
        int rango = 1;
        arma armaEquipada = jugadorObj.getEquipo().getArma();
        if (armaEquipada != null) rango = armaEquipada.getAlcance();

        enemigo objetivo = null;
        int mejorDist = Integer.MAX_VALUE;

        for (enemigo e : enemigosActuales) {
            if (!e.estaVivo()) continue;
            int dist = Math.abs(jugadorObj.getFila() - e.getFila())
                    + Math.abs(jugadorObj.getColumna() - e.getColumna());
            if (dist <= rango && dist < mejorDist) {
                mejorDist = dist;
                objetivo = e;
            }
        }

        if (objetivo == null) {
            log("No hay enemigos en rango. Acción desperdiciada.");
        } else {
            double random = rng.nextDouble();
            int dano = (int) Math.max(0,
                    jugadorObj.getAtaque() * (random * 2) - objetivo.getDefensa());
            objetivo.recibirDaño(dano);
            log("Atacaste al enemigo por " + dano + " de daño. Le quedan "
                    + objetivo.getVida() + " de vida.");
            if (!objetivo.estaVivo()) {
                habitacionActual.getData().setCelda(objetivo.getFila(), objetivo.getColumna(), 0);
                log("¡Enemigo derrotado!");
                actualizarGrid();
            }
        }
        pasarAFaseEnemigos();
        actualizarLog();
    }

    // ---------------------------------------------------------------
    // Turno de enemigos
    // ---------------------------------------------------------------
    private void pasarAFaseEnemigos() {
        faseActual = FaseTurno.ESPERA_ENEMIGOS;
        ejecutarTurnoEnemigos();
    }

    private void ejecutarTurnoEnemigos() {
        jugadorObj.reducirDuracionBuffs();

        for (enemigo e : enemigosActuales) {
            if (!e.estaVivo()) continue;
            e.realizarTurno();
            actualizarPosicionEnemigos();
            if (!jugadorObj.estaVivo()) {
                log("¡Has muerto! Fin de la partida.");
                actualizarLog();
                labelVida.setText("Vida: 0");
                deshabilitarControles();
                logPartida.vaciarMostrandoHistorial();
                return;
            }
        }

        jugadorObj.resetTurno();

        if (rutaComprada && faseActual == FaseTurno.MOVIMIENTO) {
            mostrarRutaEnLabels();
        } else if (!rutaComprada && labelRuta != null) {
            labelRuta.setText("");
        }

        faseActual = FaseTurno.MOVIMIENTO;
        venenoAplicadoEsteTurno = false;
        aplicarVenenoInicioTurno();

        actualizarGrid();
        actualizarStats();
        log("Turno de enemigos completado. Es tu turno.");
        actualizarLog();
    }

    // ---------------------------------------------------------------
    // Inventario — UI
    // ---------------------------------------------------------------
    private void mostrarInventario() {
        actualizarInventarioUI();
        if (listaInventario == null) return;

        listaInventario.setOnMouseClicked(ev -> {
            int sel = listaInventario.getSelectionModel().getSelectedIndex();
            if (sel < 0) return;
            objeto o = jugadorObj.getInventario().get(sel);
            if (o == null) return;

            if (o instanceof pocion) {
                indiceInventarioSeleccionado = sel;
                log("Seleccionaste: " + o.getNombre() + ". Pulsa 'Acción' para usarla.");
                actualizarLog();
            } else if (o instanceof arma || o instanceof armadura) {
                jugadorObj.faseInventario(o);
                log("Equipaste: " + o.getNombre());
                actualizarLog();
                actualizarInventarioUI();
                actualizarStats();
            } else {
                log(o.getNombre() + ": " + o.getDescripcion());
                actualizarLog();
            }
        });
    }

    private void actualizarInventarioUI() {
        // Actualizar Interfaz del inventario
        if (listaInventario == null) return;
        listaInventario.getItems().clear();
        for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) {
            objeto o = jugadorObj.getInventario().get(i);
            listaInventario.getItems().add(i + ". " + o.toString());
        }

        // Actualizar el equipamiento
        if (labelEquipoArma != null) labelEquipoArma.setText(
                jugadorObj.getEquipo().getArma() != null ? jugadorObj.getEquipo().getArma().getNombre() : "—");
        if (labelEquipoEscudo != null) labelEquipoEscudo.setText(
                jugadorObj.getEquipo().getEscudo() != null ? jugadorObj.getEquipo().getEscudo().getNombre() : "—");
        if (labelEquipoYelmo != null) labelEquipoYelmo.setText(
                jugadorObj.getEquipo().getYelmo() != null ? jugadorObj.getEquipo().getYelmo().getNombre() : "—");
        if (labelEquipoCoraza != null) labelEquipoCoraza.setText(
                jugadorObj.getEquipo().getCoraza() != null ? jugadorObj.getEquipo().getCoraza().getNombre() : "—");
        if (labelEquipoGrebas != null) labelEquipoGrebas.setText(
                jugadorObj.getEquipo().getGrebas() != null ? jugadorObj.getEquipo().getGrebas().getNombre() : "—");
        if (labelEquipoSabaton != null) labelEquipoSabaton.setText(
                jugadorObj.getEquipo().getSabaton() != null ? jugadorObj.getEquipo().getSabaton().getNombre() : "—");
    }

    // Actualizar el log
    private void actualizarLog() {
        if (listaLog == null) return;
        String log = logPartida.pop();
        numLog++;
        listaLog.getItems().add("[" + numLog + "] " + log);
        logPartida.push(log);
        listaLog.scrollTo(numLog);
    }

    // ---------------------------------------------------------------
    // BFS de salas para mostrar ruta comprada
    // ---------------------------------------------------------------
    private void mostrarRutaEnLabels() {
        int dist = bfsSalas();
        if (labelRuta != null) {
            labelRuta.setText("Salas hasta salida: " + dist
                    + "  |  Dist. puerta más cercana: " + distPuertaMasCercana());
        }
    }

    private int bfsSalas() {
        ListaSimplementeEnlazada<Vertice<Matriz>> cola = new ListaSimplementeEnlazada<>();
        ListaSimplementeEnlazada<Vertice<Matriz>> vistos = new ListaSimplementeEnlazada<>();
        ListaSimplementeEnlazada<Integer> distancias = new ListaSimplementeEnlazada<>();

        cola.add(habitacionActual);
        vistos.add(habitacionActual);
        distancias.add(0);

        while (!cola.isEmpty()) {
            Vertice<Matriz> actual = cola.findElement(0);
            int dist = distancias.findElement(0);
            cola.del(actual);
            distancias.del(dist);

            if (actual == habitacionFinal) return dist;

            for (int i = 0; i < actual.aristasSalida.size(); i++) {
                Vertice<Matriz> vecino = actual.aristasSalida.findElement(i).getDestino();
                if (vistos.get(vecino) == null) {
                    vistos.add(vecino);
                    cola.add(vecino);
                    distancias.add(dist + 1);
                }
            }
        }
        return -1;
    }

    private int distPuertaMasCercana() {
        Matriz m = habitacionActual.getData();
        int jF = jugadorObj.getFila();
        int jC = jugadorObj.getColumna();
        int min = Integer.MAX_VALUE;

        for (int f = 0; f < m.getFilas(); f++) {
            for (int c = 0; c < m.getColumnas(); c++) {
                int v = m.getCelda(f, c);
                if (v == 6 || v == 7 || v == 9) {
                    int d = Math.abs(f - jF) + Math.abs(c - jC);
                    if (d < min) min = d;
                }
            }
        }
        return (min == Integer.MAX_VALUE) ? -1 : min;
    }

    // ---------------------------------------------------------------
    // Renderizar el GridPane
    // ---------------------------------------------------------------
    private void actualizarGrid() {
        gridHabitacion.getChildren().clear();
        Matriz m = habitacionActual.getData();
        int numTesoros = 0;
        boolean puertaLlave = false;
        for (int f = 0; f < m.getFilas(); f++) {
            for (int c = 0; c < m.getColumnas(); c++) {
                int val = m.getCelda(f, c);
                if (val == 2) numTesoros++;
                if (val == 7) puertaLlave = true;
                String texto = switch (val) {
                    case 1 -> "P";
                    case 2 -> "T";
                    case 3 -> "T*";
                    case 4 -> "ED";
                    case 5 -> "EF";
                    case 6 -> "S";
                    case 7 -> "S🔒";
                    case 8 -> "E";
                    case 9 -> "EXIT";
                    default -> "";
                };

                Label celda = new Label(texto);
                celda.setMaxWidth(Double.MAX_VALUE);
                celda.setMaxHeight(Double.MAX_VALUE);
                celda.setAlignment(javafx.geometry.Pos.CENTER);

                String color = switch (val) {
                    case 1 -> "#4CAF50";
                    case 2 -> "#FFD700";
                    case 3 -> "#FF6600";
                    case 4 -> "#E53935";
                    case 5 -> "#B71C1C";
                    case 6, 8 -> "#2196F3";
                    case 7 -> "#9C27B0";
                    case 9 -> "#00BCD4";
                    default -> "transparent";
                };
                celda.setStyle("-fx-background-color:" + color + ";-fx-font-weight:bold;");

                if (faseActual == FaseTurno.MOVIMIENTO && esCeldaAlcanzable(f, c)) {
                    celda.setStyle(celda.getStyle() + "-fx-border-color:yellow;-fx-border-width:2;");
                }

                GridPane.setColumnIndex(celda, c);
                GridPane.setRowIndex(celda, f);
                gridHabitacion.getChildren().add(celda);
            }
        }
        boolean llaveEnInventario = false;
        for (int i = 0; i < jugadorObj.getInventario().getSize(); i++) {
            if (jugadorObj.getInventario().get(i) instanceof llave) {
                llaveEnInventario = true;
                break;
            }
        }
        if (puertaLlave && numTesoros == 0 && !llaveEnInventario) {  // Verificar si el jugador está atascado sin llave en una habitación con puerta con llave
            log("¡La puerta está bloqueada y no tienes llaves! Fin de la partida.");
            actualizarLog();
            deshabilitarControles();
            logPartida.vaciarMostrandoHistorial();
        }
    }

    private boolean esCeldaAlcanzable(int f, int c) {
        int jF = jugadorObj.getFila();
        int jC = jugadorObj.getColumna();
        int vel = jugadorObj.getVelocidad();
        if (f == jF && c != jC) return Math.abs(c - jC) <= vel;
        if (c == jC && f != jF) return Math.abs(f - jF) <= vel;
        return false;
    }

    // ---------------------------------------------------------------
    // Stats del jugador / Turnos restantes
    // ---------------------------------------------------------------
    private void actualizarStats() {
        if (labelVida != null) labelVida.setText("Vida: " + jugadorObj.getVida());
        if (labelAtaque != null) labelAtaque.setText("Ataque: " + jugadorObj.getAtaque());
        if (labelDefensa != null) labelDefensa.setText("Def: " + jugadorObj.getDefensa());
        if (labelVelocidad != null) labelVelocidad.setText("Vel: " + jugadorObj.getVelocidad());
        if (labelMovimientos != null) labelMovimientos.setText("Mov: " + jugadorObj.getVelocidad());
        if (labelTurnos != null) {
            numTurnos--;
            labelTurnos.setText("Turnos Restantes: " + numTurnos);
        }
        if (numTurnos == 0) {
            log("¡Te has quedado sin turnos! Fin de la partida.");
            actualizarLog();
            deshabilitarControles();
            logPartida.vaciarMostrandoHistorial();
        }
    }

    /**
     * Versión de actualizarStats que no decrementa el contador (usada al cargar).
     */
    private void actualizarStatsDirecto(int turnosRestantes) {
        numTurnos = turnosRestantes;
        if (labelVida != null) labelVida.setText("Vida: " + jugadorObj.getVida());
        if (labelAtaque != null) labelAtaque.setText("Ataque: " + jugadorObj.getAtaque());
        if (labelDefensa != null) labelDefensa.setText("Def: " + jugadorObj.getDefensa());
        if (labelVelocidad != null) labelVelocidad.setText("Vel: " + jugadorObj.getVelocidad());
        if (labelMovimientos != null) labelMovimientos.setText("Mov: " + jugadorObj.getVelocidad());
        if (labelTurnos != null) labelTurnos.setText("Turnos Restantes: " + numTurnos);
    }

    // ---------------------------------------------------------------
    // Utilidades
    // ---------------------------------------------------------------
    private void log(String msg) {
        logPartida.push(msg);
        if (labelMensajes != null) labelMensajes.setText(msg);
        System.out.println("[LOG] " + msg);
    }

    private void comprobarMuerte() {
        if (!jugadorObj.estaVivo()) {
            log("¡Has muerto! Fin de la partida.");
            actualizarLog();
            labelVida.setText("Vida: 0");
            deshabilitarControles();
            logPartida.vaciarMostrandoHistorial();
        }
    }

    private void deshabilitarControles() {
        if (botonMoverse != null) botonMoverse.setDisable(true);
        if (botonInventario != null) botonInventario.setDisable(true);
        if (botonAccion != null) botonAccion.setDisable(true);
        if (botonSaltarTurno != null) botonSaltarTurno.setDisable(true);
        if (botonComprarRuta != null) botonComprarRuta.setDisable(true);
        if (botonGuardarPartida != null) botonGuardarPartida.setDisable(true);
    }

    private int[] celdaVaciaAleatoria(Matriz m) {
        for (int i = 0; i < 100; i++) {
            int f = rng.nextInt(m.getFilas());
            int c = rng.nextInt(m.getColumnas());
            if (m.getCelda(f, c) == 0) return new int[]{f, c};
        }
        return new int[]{-1, -1};
    }

    private void actualizarPosicionEnemigos() {
        Matriz m = habitacionActual.getData();
        for (int f = 0; f < m.getFilas(); f++) {
            for (int c = 0; c < m.getColumnas(); c++) {
                int v = m.getCelda(f, c);
                if (v == 4 || v == 5) {
                    m.setCelda(f, c, 0);
                }
            }
        }

        for (enemigo en : enemigosActuales) {
            if (!en.estaVivo()) continue; // Si el enemigo está muerto, pasar al siguiente
            if (en.getFila() == jugadorObj.getFila() && en.getColumna() == jugadorObj.getColumna())
                continue; // Si el enemigo coincide con la posición del jugador, pasar al siguiente
            if (en.getFila() == m.getFilas() / 2 && en.getColumna() == m.getColumnas() - 1) { // Si el enemigo coincide con la posición de la puerta, desplazar al lateral de la puerta
                if (m.getFilas() / 2 < en.getUltFila()) en.setPosicion(m.getFilas() / 2, m.getColumnas() - 1);
                else if (m.getFilas() / 2 > en.getUltFila()) en.setPosicion(m.getFilas() / 2, m.getColumnas() - 1);
                if (m.getCelda(en.getFila(), m.getColumnas() - 2) == 0) {
                    en.setPosicion(en.getFila(), m.getColumnas() - 2);
                }
            }
            m.setCelda(en.getFila(), en.getColumna(), en.getTipo());
        }

        m.setCelda(m.getFilas() / 2, m.getColumnas() - 1, puertaActual.getTipo()); // Restaurar puerta en caso de ser eliminada

        m.setCelda(jugadorObj.getFila(), jugadorObj.getColumna(), 1); // Restaurar jugador en caso de ser eliminado
    }
}
