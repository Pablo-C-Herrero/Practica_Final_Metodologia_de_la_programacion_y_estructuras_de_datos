package juego.Apartado_visual.EstructurasUtilizadas;

public class ElementoSE<T>{
    public T dato;
    public ElementoSE<T> siguiente;

    public ElementoSE(T dato){
        this.dato = dato;
        this.siguiente = null;
    }
}
