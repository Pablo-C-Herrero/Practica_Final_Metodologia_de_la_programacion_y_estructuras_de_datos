package juego.Apartado_visual.EstructurasUtilizadas;

public class ElementoLC<T>{
    public T dato;
    public ElementoLC<T> siguiente;

    public ElementoLC(T dato){
        this.dato = dato;
        this.siguiente = null;
    }
}
