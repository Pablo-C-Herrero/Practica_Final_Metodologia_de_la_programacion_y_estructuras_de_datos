package juego.Apartado_visual;

import com.google.gson.Gson;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ListCell;
import javafx.stage.Stage;

import java.util.List;

/**
 * Controlador de la pantalla "Cargar Partida".
 * Muestra la lista de partidas guardadas (más nueva arriba) usando la PilaLog.
 */
public class CargarPartidaController {

    @FXML private ListView<String[]> listaPartidas;
    @FXML private Button botonCargar;
    @FXML private Button botonVolver;
    @FXML private Label labelInfo;

    @FXML
    public void initialize() {
        GestorPartidas.inicializar();

        List<String[]> partidas = GestorPartidas.obtenerListaPartidas();

        listaPartidas.getItems().addAll(partidas);

        // Mostrar solo el nombre de la partida en la celda
        listaPartidas.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(String[] item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item[0]);
            }
        });

        if (partidas.isEmpty()) {
            labelInfo.setText("No hay partidas guardadas.");
        } else {
            labelInfo.setText("Selecciona una partida para cargarla. (Arriba = más reciente)");
        }
    }

    @FXML
    protected void onCargarPartida() {
        String[] seleccionada = listaPartidas.getSelectionModel().getSelectedItem();
        if (seleccionada == null) {
            labelInfo.setText("Selecciona primero una partida de la lista.");
            return;
        }

        try {
            EstadoPartida estado = GestorPartidas.cargarDesdeJson(seleccionada[1]);

            FXMLLoader loader = new FXMLLoader(
                    PracticaFinal.class.getResource("/juego/Apartado_visual/game-view.fxml"));
            Stage gameStage = new Stage();
            Scene scene = new Scene(loader.load(), 1100, 700);
            gameStage.setTitle("Dungeon RPG — " + seleccionada[0]);
            gameStage.setScene(scene);

            JuegoController controller = loader.getController();
            controller.cargarEstado(estado);

            gameStage.show();

            // Cerrar esta ventana
            Stage thisStage = (Stage) botonVolver.getScene().getWindow();
            thisStage.close();

        } catch (Exception e) {
            e.printStackTrace();
            labelInfo.setText("Error al cargar la partida: " + e.getMessage());
        }
    }

    @FXML
    protected void onVolver() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(
                    PracticaFinal.class.getResource("/juego/Apartado_visual/title-view.fxml"));
            Stage jugar = new Stage();
            Scene scene = new Scene(fxmlLoader.load(), 900, 600);
            jugar.setTitle("Dungeon RPG");
            jugar.setScene(scene);
            jugar.show();
            Stage stage = (Stage) botonVolver.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
