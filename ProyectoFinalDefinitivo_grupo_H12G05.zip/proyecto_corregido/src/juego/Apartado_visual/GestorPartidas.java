package juego.Apartado_visual;

import com.google.gson.*;
import juego.estructuras.Pila.PilaLog;

import java.io.*;
import java.nio.file.*;

/**
 * Gestiona el guardado y la carga de partidas en JSON.
 * Usa una PilaLog<String> donde cada elemento es el JSON completo de una partida.
 * El contador de partidas se persiste en un fichero auxiliar para que sea global.
 */
public class GestorPartidas {

    // Carpeta donde se guardan los ficheros JSON de partida
    private static final String CARPETA = "out/Partidas Guardadas/";
    // Fichero que almacena el contador global de partidas guardadas
    private static final String FICHERO_CONTADOR = CARPETA + "_contador.txt";

    // Pila estática compartida por todas las instancias (una por ejecución del juego)
    private static final PilaLog<String> pilaPartidas = new PilaLog<>();
    // Nombre de cada partida en la pila (coincide con el fichero JSON)
    private static final PilaLog<String> pilaNombres  = new PilaLog<>();

    // Contador global. Se carga del disco al arrancar y se incrementa al guardar.
    private static int contadorPartidas = 0;
    private static boolean contadorCargado = false;

    // -------------------------------------------------------------------------
    // Inicialización: cargar contador y todas las partidas guardadas en disco
    // -------------------------------------------------------------------------
    public static void inicializar() {
        if (contadorCargado) return;
        contadorCargado = true;

        // Crear carpeta si no existe
        try { Files.createDirectories(Paths.get(CARPETA)); } catch (IOException ignored) {}

        // Leer contador
        try {
            String txt = Files.readString(Paths.get(FICHERO_CONTADOR)).trim();
            contadorPartidas = Integer.parseInt(txt);
        } catch (Exception ignored) {
            contadorPartidas = 0;
        }

        // Cargar partidas desde disco en orden (1, 2, 3, ...) y apilarlas
        // La más antigua se pushea primero → la más nueva queda en la cima
        for (int i = 1; i <= contadorPartidas; i++) {
            String fichero = CARPETA + "Partida " + i + ".json";
            try {
                String json = Files.readString(Paths.get(fichero));
                pilaPartidas.push(json);
                pilaNombres.push("Partida " + i);
            } catch (IOException ignored) {}
        }
    }

    // -------------------------------------------------------------------------
    // Guardar una partida
    // -------------------------------------------------------------------------
    public static String guardarPartida(EstadoPartida estado) {
        inicializar();
        contadorPartidas++;

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(estado);

        String nombre = "Partida " + contadorPartidas;
        String fichero = CARPETA + nombre + ".json";

        // Guardar en disco
        try {
            Files.createDirectories(Paths.get(CARPETA));
            Files.writeString(Paths.get(fichero), json);
            // Actualizar contador en disco
            Files.writeString(Paths.get(FICHERO_CONTADOR), String.valueOf(contadorPartidas));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Apilar en memoria
        pilaPartidas.push(json);
        pilaNombres.push(nombre);

        return nombre;
    }

    // -------------------------------------------------------------------------
    // Obtener la lista ordenada de partidas (más nueva primero = cima de la pila)
    // -------------------------------------------------------------------------
    public static java.util.List<String[]> obtenerListaPartidas() {
        // Recorremos la pila sin destruirla usando reflexión-friendly: copiamos a lista
        java.util.List<String[]> lista = new java.util.ArrayList<>();

        // Tenemos dos pilas paralelas: pilaPartidas y pilaNombres
        // Para recorrerlas sin destruirlas, usamos obtenerHistorialComoTexto como referencia
        // pero necesitamos acceso individual. Usamos una pila auxiliar temporal.
        PilaLog<String> auxJson   = new PilaLog<>();
        PilaLog<String> auxNombre = new PilaLog<>();

        // Vaciar las pilas originales a las auxiliares (invirtiendo el orden)
        while (!pilaPartidas.isEmpty()) {
            auxJson.push(pilaPartidas.pop());
            auxNombre.push(pilaNombres.pop());
        }
        // Ahora aux tiene el orden inverso (la más antigua en la cima).
        // Reconstruimos las originales y construimos la lista (más nueva primero).
        PilaLog<String> auxJson2   = new PilaLog<>();
        PilaLog<String> auxNombre2 = new PilaLog<>();

        while (!auxJson.isEmpty()) {
            String json   = auxJson.pop();
            String nombre = auxNombre.pop();
            pilaPartidas.push(json);
            pilaNombres.push(nombre);
            auxJson2.push(json);
            auxNombre2.push(nombre);
        }
        // auxJson2 y auxNombre2 ahora tienen la más nueva en la cima
        while (!auxJson2.isEmpty()) {
            String json   = auxJson2.pop();
            String nombre = auxNombre2.pop();
            lista.add(new String[]{nombre, json});
        }

        return lista;
    }

    // -------------------------------------------------------------------------
    // Cargar un JSON y convertirlo a EstadoPartida
    // -------------------------------------------------------------------------
    public static EstadoPartida cargarDesdeJson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, EstadoPartida.class);
    }

    public static PilaLog<String> getPilaLog() { return pilaPartidas; }
}
